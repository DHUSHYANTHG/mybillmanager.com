export enum VehicleType {
  BACKHOE = 'Backhoe Loader',
  LORRY = 'Tipper Lorry',
  TRACTOR = 'Tractor',
  OTHER = 'Other'
}

export interface SubscriptionData {
  planType: 'free' | '1month' | '3months' | '6months' | '1year';
  startDate: number;
  endDate: number;
  isActive: boolean;
  paymentId?: string;
  amount?: number;
  paymentMethod?: string;
}

export interface WorkLog {
  id: string;
  vehicleType: string;
  mode?: 'point_to_point' | 'shift';
  implement?: string;
  tractorWorkType?: string;
  vehicleNumber: string;
  driverName: string;
  driverPhone?: string;
  companyName: string;
  clientPhone?: string;
  location: string;
  // Point-to-Point fields
  startLocation?: string;
  endLocation?: string;
  distanceKm?: number;
  ratePerKm?: number;
  
  workDate: string;
  startTime: string;
  endTime: string;
  hoursWorked: number;
  hourlyRate: number;
  totalAmount: number;
  advancePaid: number;
  paidAmount: number;
  balanceAmount: number;
  status: 'Paid' | 'Partial' | 'Unpaid';
  timestamp: number;
}

export interface Company {
  name: string;
  totalWorkValue: number;
  totalLogs: number;
}

export interface AdminProfile {
  adminName: string;
  businessName: string;
  address: string;
  phone: string;
  email: string;
  profileImage?: string;
}

export type LanguageCode = 'en' | 'ta';

export interface AppSettings {
  language: LanguageCode;
  theme: 'light' | 'dark';
  securityEnabled: boolean;
  pin: string;
  notificationsEnabled: boolean;
}