export function shareOnWhatsApp(phone: string, message: string) {
  const clean = phone.replace(/\D/g, "");

  const url = `https://wa.me/91${clean}?text=${encodeURIComponent(message)}`;

  window.open(url, "_blank");
}
