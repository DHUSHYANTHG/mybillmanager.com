
import React, { Component, useState, useEffect, useMemo, createContext, useContext, ReactNode, ErrorInfo } from 'react';
import { 
  Truck, 
  HardHat, 
  PlusCircle, 
  Search, 
  FileText, 
  TrendingUp, 
  Wallet, 
  Clock, 
  History,
  X,
  User,
  Settings,
  LayoutDashboard,
  Users,
  Tractor as TractorIcon,
  BellRing,
  CloudDownload,
  CheckCircle2,
  ChevronDown,
  Lock,
  LogOut,
  ShieldAlert,
  Crown,
  Loader2,
  WifiOff,
  RefreshCw,
  Hash
} from 'lucide-react';
import { WorkLog, VehicleType, AppSettings, LanguageCode, SubscriptionData } from './types';
import { DashboardCard } from './components/DashboardCard';
import { getWorkSummary } from './services/geminiService';
import { WorkDetails } from './components/WorkDetails';
import { ProfileView } from './components/ProfileView';
import { RevenueAnalytics } from './components/RevenueAnalytics';
import { ClientsList } from './components/ClientsList';
import { SettingsView } from './components/SettingsView';
import { LoginView } from './components/LoginView';
import { ForgotPinModal } from './components/ForgotPinModal';
import { SubscriptionView } from './components/SubscriptionView';
import { translations } from './translations';

// --- Custom Hooks ---
const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
};

// --- Error Boundary ---
interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false
    };
  }

  public static getDerivedStateFromError(_: Error): ErrorBoundaryState { 
    return { hasError: true }; 
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) { 
    console.error("Boundary error:", error, errorInfo); 
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-slate-50 text-center">
          <h1 className="text-2xl font-bold mb-2">Something went wrong</h1>
          <p className="text-slate-500 mb-6">The application encountered a runtime error.</p>
          <button onClick={() => window.location.reload()} className="px-6 py-3 bg-amber-500 text-white rounded-xl font-bold">Refresh Application</button>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Language Context ---
interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: keyof typeof translations['en']) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within a LanguageProvider");
  return context;
};

const LanguageProvider = ({ children }: React.PropsWithChildren<{}>) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      return (localStorage.getItem('app_language') as LanguageCode) || 'en';
    } catch (e) {
      return 'en';
    }
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    localStorage.setItem('app_language', lang);
  };

  const t = useMemo(() => (key: keyof typeof translations['en']): string => {
    try {
      const dict = translations[language] || translations['en'] || {};
      const val = dict[key] || translations['en'][key] || key;
      return typeof val === 'string' ? val : String(val);
    } catch (e) {
      return key as string;
    }
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

const TRACTOR_WORK_TYPES = [
  'cultivator5', 'cultivator7', 'cultivator9', 'rotavator36', 'rotavator40',
  'cageWheel', 'tipperBox', 'harvester', 'powerWeeder', 'sorghumThresher', 'waterTanker'
];

type AppView = '/' | '/history' | '/profile' | '/settings';
type BillingMode = 'hourly' | 'distance';
type MachineCategory = 'backhoe' | 'lorry' | 'tractor' | 'others';

const SCHEDULED_HOURS = [9, 12, 14, 17, 19, 21];
const PERSISTENT_BACKUP_KEY = 'HEAVY_FLOW_PERSISTENT_BACKUP';
const SUBSCRIPTION_KEY = 'heavy_flow_subscription';
const SUBSCRIPTION_HISTORY_KEY = 'heavy_flow_subscription_history';
const AUTH_KEY = 'heavy_flow_auth_persistent';

const AppContent: React.FC = () => {
  const isOnline = useNetworkStatus();
  const { language, t, setLanguage } = useLanguage();
  const [logs, setLogs] = useState<WorkLog[]>([]);
  const [currentView, setCurrentView] = useState<AppView>('/');
  const [isAdding, setIsAdding] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [showRevenueAnalytics, setShowRevenueAnalytics] = useState(false);
  const [showClientsList, setShowClientsList] = useState(false);
  const [selectedLog, setSelectedLog] = useState<WorkLog | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'balance' | 'paid'>('all');
  const [aiSummary, setAiSummary] = useState(t('generatingInsights'));
  const [activeNotification, setActiveNotification] = useState<string | null>(null);
  const [hasCloudBackup, setHasCloudBackup] = useState(false);
  
  const [pinPromptLog, setPinPromptLog] = useState<WorkLog | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [showForgotPin, setShowForgotPin] = useState(false);
  
  // Subscription State
  const [subscription, setSubscription] = useState<SubscriptionData | null>(() => {
    try {
      const saved = localStorage.getItem(SUBSCRIPTION_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  const [subscriptionHistory, setSubscriptionHistory] = useState<SubscriptionData[]>(() => {
    try {
      const saved = localStorage.getItem(SUBSCRIPTION_HISTORY_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('heavy_flow_settings');
      const baseSettings: AppSettings = {
        language: (localStorage.getItem('app_language') as LanguageCode) || 'en',
        theme: 'light',
        securityEnabled: false,
        pin: '',
        notificationsEnabled: false
      };
      if (saved) return { ...baseSettings, ...JSON.parse(saved) };
      return baseSettings;
    } catch (e) {
      return { language: 'en', theme: 'light', securityEnabled: false, pin: '', notificationsEnabled: false };
    }
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem(AUTH_KEY) === 'true';
  });

  // Initialize Free Year for new users and update history
  useEffect(() => {
    if (isAuthenticated && !subscription) {
      const now = Date.now();
      const expiry = new Date();
      expiry.setFullYear(expiry.getFullYear() + 1);
      
      const freeTrial: SubscriptionData = {
        planType: 'free',
        startDate: now,
        endDate: expiry.getTime(),
        isActive: true,
        amount: 0,
        paymentMethod: 'N/A'
      };
      
      setSubscription(freeTrial);
      localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(freeTrial));
      
      const history = [freeTrial];
      setSubscriptionHistory(history);
      localStorage.setItem(SUBSCRIPTION_HISTORY_KEY, JSON.stringify(history));
    }
  }, [isAuthenticated, subscription]);

  const subscriptionStatus = useMemo(() => {
    if (!subscription) return { expired: false, warning: false };
    const now = Date.now();
    const isExpired = now > subscription.endDate;
    const timeLeft = subscription.endDate - now;
    const isWarning = timeLeft > 0 && timeLeft < 7 * 24 * 60 * 60 * 1000; // 7 days warning
    return { expired: isExpired, warning: isWarning };
  }, [subscription]);

  const [machineCategory, setMachineCategory] = useState<MachineCategory>('backhoe');
  const [entryMode, setEntryMode] = useState<BillingMode>('hourly');
  const [tractorWorkType, setTractorWorkType] = useState(TRACTOR_WORK_TYPES[0]);
  const [customWorkType, setCustomWorkType] = useState('');

  useEffect(() => {
    if (settings.language !== language) setLanguage(settings.language);
  }, [settings.language, language, setLanguage]);

  useEffect(() => {
    const backup = localStorage.getItem(PERSISTENT_BACKUP_KEY);
    if (backup && logs.length === 0) setHasCloudBackup(true);
  }, [logs.length]);

  const handleRestoreBackup = () => {
    try {
      const backupStr = localStorage.getItem(PERSISTENT_BACKUP_KEY);
      if (!backupStr) return;
      const backup = JSON.parse(backupStr);
      if (backup.logs) {
        setLogs(backup.logs);
        localStorage.setItem('heavy_flow_logs', JSON.stringify(backup.logs));
      }
      if (backup.settings) {
        setSettings(backup.settings);
        localStorage.setItem('heavy_flow_settings', JSON.stringify(backup.settings));
        if (backup.settings.language) setLanguage(backup.settings.language);
      }
      if (backup.profile) localStorage.setItem('heavy_flow_profile', JSON.stringify(backup.profile));
      setHasCloudBackup(false);
      fetchSummary(backup.logs || []);
    } catch (e) {
      console.error("Restore failed", e);
    }
  };

  const [formData, setFormData] = useState<Partial<WorkLog>>({
    vehicleType: VehicleType.BACKHOE,
    workDate: new Date().toISOString().split('T')[0],
    hourlyRate: 1500,
    advancePaid: 0,
    paidAmount: 0,
    hoursWorked: 0,
    location: '',
    companyName: '',
    clientPhone: '',
    driverName: '',
    vehicleNumber: '',
    startTime: '09:00',
    endTime: '17:00',
    startLocation: '',
    endLocation: '',
    distanceKm: 0,
    ratePerKm: 50
  });

  useEffect(() => {
    if (machineCategory === 'lorry') setEntryMode('distance');
    else if (machineCategory === 'tractor') setEntryMode('distance');
    else setEntryMode('hourly');
  }, [machineCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (!settings.notificationsEnabled) return;
      const now = new Date();
      if (SCHEDULED_HOURS.includes(now.getHours())) {
        const slotKey = `${now.toISOString().split('T')[0]}-${now.getHours()}`;
        if (localStorage.getItem('last_notified_slot') !== slotKey) {
          const pending = logs.filter(l => (l.balanceAmount || 0) > 0);
          if (pending.length > 0) {
            setActiveNotification(`${t('paymentPending')}: ${pending.length} ${t('recordsFound')}.`);
            localStorage.setItem('last_notified_slot', slotKey);
          }
        }
      }
    }, 60000);
    return () => clearInterval(interval);
  }, [settings.notificationsEnabled, logs, t]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('heavy_flow_logs');
      if (saved) {
        const parsed = JSON.parse(saved);
        setLogs(parsed);
        fetchSummary(parsed);
      }
    } catch (e) {
      console.error("Failed to load logs", e);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('heavy_flow_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('heavy_flow_settings', JSON.stringify(settings));
    if (settings.theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [settings]);

  const liveBilling = useMemo(() => {
    let total = entryMode === 'distance' ? (formData.distanceKm || 0) * (formData.ratePerKm || 0) : (formData.hoursWorked || 0) * (formData.hourlyRate || 0);
    const advance = formData.advancePaid || 0;
    const isPhoneValid = /^[0-9]{10}$/.test(formData.clientPhone || '');
    let isInputValid = (formData.companyName?.trim() || '') !== '' && (formData.driverName?.trim() || '') !== '' && isPhoneValid;
    
    if (entryMode === 'distance') {
      isInputValid = isInputValid && (formData.startLocation?.trim() || '') !== '' && (formData.endLocation?.trim() || '') !== '';
    }

    if (machineCategory === 'others') {
      isInputValid = isInputValid && customWorkType.trim() !== '';
    }

    return { total, balance: total - advance, isValid: isInputValid };
  }, [formData, entryMode, machineCategory, customWorkType]);

  const fetchSummary = async (currentLogs: WorkLog[]) => {
    if (currentLogs.length > 0) setAiSummary(await getWorkSummary(currentLogs.slice(0, 5), language));
  };

  const handleUpdateLog = (updatedLog: WorkLog) => {
    setLogs(prev => prev.map(l => l.id === updatedLog.id ? updatedLog : l));
    setSelectedLog(updatedLog);
  };

  const handleMarkAsPaid = (log: WorkLog) => {
    handleUpdateLog({ ...log, paidAmount: (log.totalAmount || 0) - (log.advancePaid || 0), balanceAmount: 0, status: 'Paid' });
  };

  const verifyGlobalPin = () => {
    if (pinInput === settings.pin) {
      if (pinPromptLog) {
        handleMarkAsPaid(pinPromptLog);
      }
      setPinPromptLog(null);
      setPinInput('');
      setPinError(false);
    } else {
      setPinError(true);
      setPinInput('');
    }
  };

  const generateSafeId = () => {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  };

  const handleAddLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveBilling.isValid || isSaving) return;

    setIsSaving(true);
    setSaveStatus('idle');

    try {
      await new Promise(resolve => setTimeout(resolve, 800));

      const totalPaid = (formData.advancePaid || 0) + (formData.paidAmount || 0);
      const balance = liveBilling.total - totalPaid;
      const newLog: WorkLog = {
        ...formData as any,
        id: generateSafeId(),
        mode: entryMode === 'distance' ? 'point_to_point' : 'shift',
        vehicleType: machineCategory === 'others' ? customWorkType : (machineCategory === 'tractor' ? VehicleType.TRACTOR : machineCategory === 'lorry' ? VehicleType.LORRY : machineCategory === 'backhoe' ? VehicleType.BACKHOE : 'Other'),
        tractorWorkType: machineCategory === 'tractor' ? t(tractorWorkType as any) : undefined,
        totalAmount: liveBilling.total,
        balanceAmount: balance,
        status: balance <= 0 ? 'Paid' : totalPaid > 0 ? 'Partial' : 'Unpaid',
        timestamp: Date.now()
      };
      
      setLogs(prev => [newLog, ...prev]);
      setSaveStatus('success');
      
      setTimeout(() => {
        setIsAdding(false);
        setCustomWorkType('');
        setIsSaving(false);
        setSaveStatus('idle');
      }, 1000);
    } catch (err) {
      console.error("Save failed", err);
      setSaveStatus('error');
      setIsSaving(false);
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const stats = useMemo(() => {
    const totalEarnings = logs.reduce((sum, log) => sum + (log.totalAmount || 0), 0);
    const totalPending = logs.reduce((sum, log) => sum + (log.balanceAmount || 0), 0);
    const totalPaid = logs.reduce((sum, log) => sum + ((log.advancePaid || 0) + (log.paidAmount || 0)), 0);
    const companies = new Set(logs.map(l => (l.companyName || '').trim().toLowerCase())).size;
    return { totalEarnings, totalPending, totalPaid, companies };
  }, [logs]);

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const match = (log.companyName || '').toLowerCase().includes(searchTerm.toLowerCase());
      const statusMatch = historyFilter === 'all' || (historyFilter === 'balance' && (log.balanceAmount || 0) > 0) || (historyFilter === 'paid' && (log.balanceAmount || 0) === 0);
      return match && statusMatch;
    });
  }, [logs, searchTerm, historyFilter]);

  const navigateTo = (view: AppView) => {
    setCurrentView(view);
    setSelectedLog(null);
    setShowRevenueAnalytics(false);
    setShowClientsList(false);
  };

  const handleSuccessLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem(AUTH_KEY, 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(AUTH_KEY);
    navigateTo('/');
  };

  // Consolidated function to update both active subscription and history
  const handleUpdateSubscription = (data: SubscriptionData) => {
    setSubscription(data);
    localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(data));
    setSubscriptionHistory(prev => {
      const updated = [data, ...prev];
      localStorage.setItem(SUBSCRIPTION_HISTORY_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  if (!isAuthenticated) {
    return (
      <LoginView 
        onLogin={handleSuccessLogin} 
        settings={settings} 
        onUpdateSettings={setSettings}
        t={t}
      />
    );
  }

  // Blocking view for expired subscription
  if (subscriptionStatus.expired) {
    return (
      <SubscriptionView 
        t={t} 
        onPlanActivated={handleUpdateSubscription} 
      />
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${settings.theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} pb-28`}>
      
      {/* Network Status Toast */}
      {!isOnline && (
        <div className="fixed top-0 left-0 right-0 z-[1000] bg-rose-600 text-white py-2 px-4 flex items-center justify-center gap-2 animate-in slide-in-from-top duration-300">
          <WifiOff size={16} />
          <span className="text-xs font-bold uppercase tracking-widest">Offline Mode - Cloud features restricted</span>
          <button onClick={() => window.location.reload()} className="ml-2 bg-white/20 p-1 rounded-md"><RefreshCw size={12} /></button>
        </div>
      )}

      {activeNotification && (
        <div className="fixed top-20 left-4 right-4 z-[500] animate-in slide-in-from-top-4 fade-in">
          <div className="bg-amber-500 text-white p-4 rounded-2xl shadow-2xl flex items-center justify-between">
            <div className="flex items-center gap-3"><BellRing size={20} /><p className="text-sm font-bold">{activeNotification}</p></div>
            <button onClick={() => setActiveNotification(null)}><X size={20} /></button>
          </div>
        </div>
      )}

      {saveStatus === 'success' && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[1000] animate-in slide-in-from-top-8 duration-500">
           <div className="bg-emerald-500 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 font-bold whitespace-nowrap">
             <CheckCircle2 size={18} />
             <span>Saved Successfully</span>
           </div>
        </div>
      )}

      {subscriptionStatus.warning && (
        <div className="bg-rose-500 text-white text-[10px] py-1 text-center font-black uppercase tracking-widest sticky top-0 z-[110] flex items-center justify-center gap-2">
          <ShieldAlert size={12} />
          {t('expiryWarning')} - {t('subscriptionExpiresOn')}: {new Date(subscription?.endDate || 0).toLocaleDateString()}
        </div>
      )}

      {selectedLog && (
        <div className="z-[100] fixed inset-0">
          <WorkDetails log={selectedLog} onBack={() => setSelectedLog(null)} onUpdate={handleUpdateLog} settings={settings} t={t} />
        </div>
      )}

      {currentView === '/profile' && <ProfileView onBack={() => navigateTo('/')} settings={settings} t={t} />}
      {showRevenueAnalytics && <RevenueAnalytics logs={logs} onBack={() => setShowRevenueAnalytics(false)} settings={settings} t={t} />}
      {showClientsList && <ClientsList logs={logs} onBack={() => setShowClientsList(false)} onSelectLog={setSelectedLog} settings={settings} t={t} />}
      {/* Fixed: Added missing subscriptionHistory prop and used handleUpdateSubscription */}
      {currentView === '/settings' && <SettingsView settings={settings} onUpdateSettings={setSettings} subscription={subscription} subscriptionHistory={subscriptionHistory} subscriptionStatus={subscriptionStatus} onUpdateSubscription={handleUpdateSubscription} onLogout={handleLogout} onBack={() => navigateTo('/')} t={t} />}

      <header className="bg-white border-b sticky top-0 z-30 dark:bg-slate-900 dark:border-slate-800 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-black dark:text-white">My Bill <span className="text-amber-500">Manager</span></h1>
          <div className="flex items-center gap-3">
             <button onClick={() => setIsAdding(true)} className="bg-amber-500 text-white px-4 py-2 rounded-xl flex items-center gap-2 font-bold shadow-lg shadow-amber-500/20 active:scale-95 transition-all">
              <PlusCircle size={20} /><span>{t('addEntry')}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        {currentView === '/' ? (
          <div className="space-y-8">
            {hasCloudBackup && logs.length === 0 && (
              <div className="bg-white p-6 rounded-[2rem] border border-amber-200 shadow-xl flex items-center justify-between dark:bg-slate-900 dark:border-amber-900/30">
                <div className="flex items-center gap-4"><CloudDownload size={24} className="text-amber-500" /><div><h3 className="font-black dark:text-white">{t('restore')}</h3><p className="text-[10px] text-slate-400 uppercase">{t('backupFound')}</p></div></div>
                <button onClick={handleRestoreBackup} className="px-6 py-3 bg-amber-500 text-white rounded-xl font-bold text-[10px] uppercase">{t('restore')}</button>
              </div>
            )}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-100 p-5 rounded-2xl flex items-start gap-4 dark:from-amber-900/10 dark:to-orange-900/10">
              <TrendingUp className="text-amber-600 w-6 h-6 mt-1" />
              <div><h3 className="font-bold text-amber-900 text-xs uppercase dark:text-amber-400">{t('insights')}</h3><p className="text-amber-800 mt-1 text-sm dark:text-amber-200/90">{aiSummary}</p></div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <DashboardCard title={t('revenue')} value={`₹${stats.totalEarnings.toLocaleString()}`} icon={<Wallet className="text-emerald-600" />} color="bg-emerald-50 dark:bg-emerald-900/30" onClick={() => setShowRevenueAnalytics(true)} />
              <DashboardCard title={t('balance')} value={`₹${stats.totalPending.toLocaleString()}`} icon={<Clock className="text-rose-600" />} color="bg-rose-50 dark:bg-rose-900/30" />
              <DashboardCard title={t('paid')} value={`₹${stats.totalPaid.toLocaleString()}`} icon={<FileText className="text-blue-600" />} color="bg-blue-50 dark:bg-blue-900/30" />
              <DashboardCard title={t('clients')} value={stats.companies} icon={<Users className="text-amber-600" />} color="bg-amber-50 dark:bg-amber-900/30" onClick={() => setShowClientsList(true)} />
            </div>
          </div>
        ) : currentView === '/history' ? (
          <div className="space-y-6">
            <div className="relative"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /><input type="text" placeholder={t('searchPlaceholder')} className="w-full pl-12 pr-4 py-4 bg-white border rounded-2xl dark:bg-slate-900 dark:border-slate-800 dark:text-white" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div>
            <div className="grid grid-cols-3 gap-3">
              <button onClick={() => setHistoryFilter('all')} className={`p-3 rounded-2xl border ${historyFilter === 'all' ? 'bg-amber-500 text-white' : 'bg-white dark:bg-slate-900'}`}>{t('all')}</button>
              <button onClick={() => setHistoryFilter('balance')} className={`p-3 rounded-2xl border ${historyFilter === 'balance' ? 'bg-rose-500 text-white' : 'bg-white dark:bg-slate-900'}`}>{t('balance')}</button>
              <button onClick={() => setHistoryFilter('paid')} className={`p-3 rounded-2xl border ${historyFilter === 'paid' ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-900'}`}>{t('paid')}</button>
            </div>
            <div className="space-y-4">
              {filteredLogs.map(log => (
                <div key={log.id} className="relative">
                  <button onClick={() => setSelectedLog(log)} className="w-full text-left bg-white p-4 rounded-2xl border shadow-sm dark:bg-slate-900 dark:border-slate-800">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className={`p-3 rounded-xl ${log.vehicleType === VehicleType.BACKHOE ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                          {log.vehicleType === VehicleType.BACKHOE ? <HardHat size={20} /> : <Truck size={20} />}
                        </div>
                        <div>
                          <h4 className="font-bold dark:text-white truncate max-w-[150px]">{log.companyName}</h4>
                          <div className="flex items-center gap-2">
                            <p className="text-[10px] text-slate-400 uppercase font-bold">{log.workDate}</p>
                            {log.vehicleNumber && (
                              <span className="text-[8px] px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded font-black border dark:border-slate-700">{log.vehicleNumber}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right"><div className="text-base font-black dark:text-white">₹{log.totalAmount.toLocaleString()}</div><div className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${log.status === 'Paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{t(log.status.toLowerCase() as any)}</div></div>
                    </div>
                  </button>
                  {(log.balanceAmount || 0) > 0 && (
                    <button 
                      onClick={e => { 
                        e.stopPropagation(); 
                        if (settings.securityEnabled) {
                          setPinPromptLog(log);
                        } else {
                          handleMarkAsPaid(log);
                        }
                      }} 
                      className="absolute bottom-3.5 right-20 px-3 py-1.5 rounded-xl flex items-center gap-1.5 bg-emerald-50 text-emerald-600 border border-emerald-100 active:scale-95 transition-all"
                    >
                      <CheckCircle2 size={12} /> <span className="text-[9px] font-black uppercase">{t('markAsPaid')}</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t px-4 py-3 flex justify-around items-center z-[120] dark:bg-slate-900 dark:border-slate-800 shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <button onClick={() => navigateTo('/')} className={`flex flex-col items-center gap-1 ${currentView === '/' ? 'text-amber-500' : 'text-slate-400'}`}><LayoutDashboard size={20} /><span className="text-[10px] font-bold">{t('home')}</span></button>
        <button onClick={() => navigateTo('/history')} className={`flex flex-col items-center gap-1 ${currentView === '/history' ? 'text-amber-500' : 'text-slate-400'}`}><History size={20} /><span className="text-[10px] font-bold">{t('history')}</span></button>
        <button onClick={() => navigateTo('/profile')} className={`flex flex-col items-center gap-1 ${currentView === '/profile' ? 'text-amber-500' : 'text-slate-400'}`}><User size={20} /><span className="text-[10px] font-bold">{t('profile')}</span></button>
        <button onClick={() => navigateTo('/settings')} className={`flex flex-col items-center gap-1 ${currentView === '/settings' ? 'text-amber-500' : 'text-slate-400'}`}><Settings size={20} /><span className="text-[10px] font-bold">{t('settings')}</span></button>
      </nav>

      {isAdding && (
        <div className="fixed inset-0 z-[200] flex flex-col bg-slate-900/60 backdrop-blur-sm pointer-events-auto">
          <div className="bg-white w-full max-w-xl mx-auto sm:rounded-3xl shadow-2xl h-full sm:h-[95dvh] sm:mt-8 flex flex-col dark:bg-slate-900 animate-in slide-in-from-bottom-8 duration-300 overflow-hidden relative">
            <div className="p-6 border-b flex justify-between items-center dark:border-slate-800 shrink-0">
              <h2 className="text-xl font-bold flex items-center gap-2 dark:text-white"><PlusCircle className="text-amber-500" />{t('addEntry')}</h2>
              <button onClick={() => setIsAdding(false)} className="p-2 text-slate-400 hover:bg-slate-100 rounded-full dark:hover:bg-slate-800 transition-colors"><X size={24} /></button>
            </div>
            
            <form onSubmit={handleAddLog} className="flex-1 overflow-y-auto flex flex-col scroll-smooth">
              <div className="p-6 space-y-6 touch-pan-y flex-1" style={{ paddingBottom: 'calc(100px + env(safe-area-inset-bottom, 24px))' }}>
                <div className="grid grid-cols-4 gap-2">
                  {(['backhoe', 'lorry', 'tractor', 'others'] as MachineCategory[]).map(cat => (
                    <button key={cat} type="button" onClick={() => setMachineCategory(cat)} className={`py-3 rounded-2xl border-2 font-bold text-[10px] flex flex-col items-center gap-1.5 transition-all ${machineCategory === cat ? 'bg-amber-500 border-amber-500 text-white' : 'bg-white border-slate-100 text-slate-400 dark:bg-slate-800 dark:border-slate-700'}`}>
                      {cat === 'backhoe' ? <HardHat size={18} /> : cat === 'lorry' ? <Truck size={18} /> : cat === 'tractor' ? <TractorIcon size={18} /> : <FileText size={18} />}
                      <span className="capitalize">{t(cat as any)}</span>
                    </button>
                  ))}
                </div>

                {machineCategory === 'others' && (
                  <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('customWorkType')}</label>
                    <input 
                      type="text" 
                      placeholder={t('customWorkTypePlaceholder')} 
                      className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" 
                      value={customWorkType} 
                      onChange={e => setCustomWorkType(e.target.value)}
                      required
                    />
                  </div>
                )}

                {machineCategory === 'tractor' && (
                  <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('tractorWorkTypeLabel')}</label>
                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                      {TRACTOR_WORK_TYPES.map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setTractorWorkType(type)}
                          className={`p-3 text-[10px] font-bold rounded-xl border text-left transition-all ${tractorWorkType === type ? 'bg-amber-500 border-amber-500 text-white' : 'bg-white dark:bg-slate-900 dark:border-slate-700 text-slate-600 dark:text-slate-400'}`}
                        >
                          {t(type as any)}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <input type="date" className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.workDate} onChange={e => setFormData({...formData, workDate: e.target.value})} />
                  <input type="text" placeholder={t('clientName')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 font-bold" required value={formData.companyName} onChange={e => setFormData({...formData, companyName: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <input type="tel" maxLength={10} placeholder={t('clientPhone')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.clientPhone} onChange={e => setFormData({...formData, clientPhone: e.target.value.replace(/\D/g, '')})} />
                  <input type="text" placeholder={t('driver')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.driverName} onChange={e => setFormData({...formData, driverName: e.target.value})} />
                </div>
                
                {/* Vehicle Number Input Field */}
                <div className="space-y-1 animate-in slide-in-from-top-2 duration-300">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">{t('vehicleNumber')}</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors pointer-events-none">
                      <Hash size={18} />
                    </div>
                    <input 
                      type="text" 
                      placeholder="TN 28 AS 2323" 
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 font-bold uppercase" 
                      value={formData.vehicleNumber || ''} 
                      onChange={e => setFormData({...formData, vehicleNumber: e.target.value})} 
                    />
                  </div>
                </div>
                
                <div className="flex bg-slate-100 p-1 rounded-2xl dark:bg-slate-800">
                  <button type="button" onClick={() => setEntryMode('hourly')} className={`flex-1 py-2 text-[10px] font-bold rounded-xl transition-all ${entryMode === 'hourly' ? 'bg-white text-amber-600 shadow-sm dark:bg-slate-700' : 'text-slate-500'}`}>{t('shiftMode')}</button>
                  <button type="button" onClick={() => setEntryMode('distance')} className={`flex-1 py-2 text-[10px] font-bold rounded-xl transition-all ${entryMode === 'distance' ? 'bg-white text-amber-600 shadow-sm dark:bg-slate-700' : 'text-slate-500'}`}>{t('pointToPoint')}</button>
                </div>

                {entryMode === 'distance' ? (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="grid grid-cols-2 gap-4">
                      <input type="text" placeholder={t('startLocation')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" required value={formData.startLocation || ''} onChange={e => setFormData({...formData, startLocation: e.target.value})} />
                      <input type="text" placeholder={t('endLocation')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" required value={formData.endLocation || ''} onChange={e => setFormData({...formData, endLocation: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <input type="number" placeholder={t('distanceKm')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.distanceKm || ''} onChange={e => setFormData({...formData, distanceKm: parseFloat(e.target.value) || 0})} />
                      <input type="number" placeholder={t('ratePerKm')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.ratePerKm || ''} onChange={e => setFormData({...formData, ratePerKm: parseFloat(e.target.value) || 0})} />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4 animate-in fade-in duration-300">
                    <input type="number" step="0.5" placeholder={t('totalHours')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.hoursWorked || ''} onChange={e => setFormData({...formData, hoursWorked: parseFloat(e.target.value) || 0})} />
                    <input type="number" placeholder={t('rateHr')} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-amber-500 font-bold" value={formData.hourlyRate || ''} onChange={e => setFormData({...formData, hourlyRate: parseFloat(e.target.value) || 0})} />
                  </div>
                )}

                <div className="space-y-1 animate-in slide-in-from-top-2 duration-300">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">{t('advancePay')}</label>
                  <input 
                    type="number" 
                    placeholder={t('advancePay')} 
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500 font-bold" 
                    value={formData.advancePaid || ''} 
                    onChange={e => setFormData({...formData, advancePaid: parseFloat(e.target.value) || 0})} 
                  />
                </div>
                
                <div className="p-5 bg-amber-50 rounded-3xl border border-amber-100 grid grid-cols-3 gap-2 dark:bg-amber-900/10 dark:border-amber-900/30 transition-all mb-8">
                  <div className="text-left">
                    <p className="text-[8px] font-bold text-amber-600 uppercase tracking-widest">{t('totalBill')}</p>
                    <p className="text-sm font-black text-amber-600">₹{liveBilling.total.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[8px] font-bold text-amber-600 uppercase tracking-widest">{t('advancePaidLabel')}</p>
                    <p className="text-sm font-black text-amber-600">₹{(formData.advancePaid || 0).toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[8px] font-bold text-amber-600 uppercase tracking-widest">{t('pendingBalance')}</p>
                    <p className="text-sm font-black text-amber-600">₹{liveBilling.balance.toLocaleString()}</p>
                  </div>
                </div>

                <div className="pt-4">
                  <button 
                    type="submit" 
                    disabled={!liveBilling.isValid || isSaving} 
                    className="w-full py-5 bg-amber-500 text-white rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-amber-500/30 active:scale-95 transition-all disabled:opacity-40 disabled:scale-100 flex items-center justify-center gap-3 relative z-[300] pointer-events-auto"
                  >
                    {isSaving ? (
                      <>
                        {saveStatus === 'success' ? <CheckCircle2 className="animate-in zoom-in" /> : <Loader2 className="animate-spin" />}
                        <span>{saveStatus === 'success' ? 'Saved!' : 'Saving...'}</span>
                      </>
                    ) : (
                      <>
                        <FileText size={20} />
                        <span>{t('save')}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {pinPromptLog && (
        <div className="fixed inset-0 z-[500] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-sm rounded-3xl p-6 shadow-2xl space-y-6 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
            <div className="text-center">
              <div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-amber-900/20">
                <Lock className="text-amber-500" size={32} />
              </div>
              <h2 className="text-xl font-bold dark:text-white">{t('enterPin')}</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">{t('verifyPinSub')}</p>
            </div>
            
            <input 
              type="password" 
              inputMode="numeric" 
              maxLength={6} 
              autoFocus 
              className={`w-full p-5 bg-slate-50 border rounded-2xl text-center text-3xl font-black tracking-[0.5em] outline-none dark:bg-slate-800 dark:text-white transition-all ${pinError ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-slate-200 focus:border-amber-500'}`} 
              placeholder="••••" 
              value={pinInput} 
              onChange={e => {setPinInput(e.target.value.replace(/\D/g, '')); setPinError(false);}} 
              onKeyDown={e => e.key === 'Enter' && verifyGlobalPin()} 
            />
            
            {pinError && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{t('incorrectPin')}</p>}
            
            <div className="flex justify-end px-1">
              <button 
                type="button" 
                onClick={() => setShowForgotPin(true)}
                className="text-xs font-bold text-amber-600 dark:text-amber-500 hover:underline"
              >
                {t('forgotPin')}
              </button>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => {setPinPromptLog(null); setPinInput(''); setPinError(false);}} 
                className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300"
              >
                {t('cancel')}
              </button>
              <button 
                onClick={verifyGlobalPin} 
                className="flex-1 py-4 bg-amber-500 text-white rounded-2xl font-bold shadow-lg shadow-amber-500/20"
              >
                {t('verify')}
              </button>
            </div>
          </div>
        </div>
      )}

      {showForgotPin && (
        <ForgotPinModal 
          t={t} 
          onBack={() => setShowForgotPin(false)}
          onSuccess={(newPin) => {
            const currentSettings = JSON.parse(localStorage.getItem('heavy_flow_settings') || '{}');
            const updatedSettings = { ...currentSettings, pin: newPin };
            localStorage.setItem('heavy_flow_settings', JSON.stringify(updatedSettings));
            setSettings(updatedSettings);
            setShowForgotPin(false);
            alert(t('pinResetSuccess'));
          }}
        />
      )}
    </div>
  );
};

// App component with Login layer
const App = () => (
  <ErrorBoundary>
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  </ErrorBoundary>
);

export default App;
