
import { GoogleGenAI } from "@google/genai";
import { WorkLog, LanguageCode } from "../types";

// Delay helper for exponential backoff
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getWorkSummary = async (logs: WorkLog[], language: LanguageCode, retries = 3) => {
  if (!navigator.onLine) {
    return language === 'ta' ? "இணைய இணைப்பு இல்லை." : "No internet connection.";
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const logSummary = logs.map(l => 
      `${l.workDate}: ${l.vehicleType} at ${l.location} for ${l.companyName}. Total: ${l.totalAmount}.`
    ).join('\n');

    const languageName = language === 'ta' ? 'Tamil' : 'English';

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze these machinery work logs and provide a brief 2-sentence business summary in ${languageName} focusing on productivity and financial health: \n${logSummary}`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || (language === 'ta' ? "சுருக்கம் கிடைக்கவில்லை." : "Summary unavailable.");
  } catch (error) {
    console.error("Gemini Error:", error);
    
    // Auto-retry logic for network switching or timeout
    if (retries > 0) {
      await delay(1500 * (4 - retries)); // Exponential backoff
      return getWorkSummary(logs, language, retries - 1);
    }
    
    return language === 'ta' ? "AI சுருக்கத்தை உருவாக்க முடியவில்லை." : "Could not generate AI summary.";
  }
};
