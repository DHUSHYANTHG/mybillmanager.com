import React, { useState, useEffect } from 'react';
import { Phone, Lock, Eye, EyeOff, Globe, HardHat, Truck, User, Building, MapPin, CheckCircle } from 'lucide-react';
import { translations } from '../translations';
import { AdminProfile, AppSettings, LanguageCode } from '../types';
import { ForgotPinModal } from './ForgotPinModal';

interface LoginViewProps {
  onLogin: () => void;
  settings: AppSettings;
  onUpdateSettings: (s: AppSettings) => void;
  t: (key: keyof typeof translations['en']) => string;
}

type AuthMode = 'login' | 'signup';

export const LoginView: React.FC<LoginViewProps> = ({ onLogin, settings, onUpdateSettings, t }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [adminName, setAdminName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [address, setAddress] = useState('');
  
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  useEffect(() => {
    // Check if account exists, otherwise default to signup
    const savedProfile = localStorage.getItem('heavy_flow_profile');
    if (!savedProfile) {
      setMode('signup');
    } else {
      setMode('login');
    }
  }, []);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'signup') {
      if (!adminName.trim() || !businessName.trim() || !address.trim() || phone.length !== 10 || pin.length < 4) {
        setError('Please fill all mandatory fields correctly');
        return;
      }
      if (pin !== confirmPin) {
        setError('PINs do not match');
        return;
      }
      
      // Initialize account
      const newProfile: AdminProfile = {
        adminName: adminName.trim(),
        businessName: businessName.trim(),
        address: address.trim(),
        phone: phone,
        email: '' 
      };
      localStorage.setItem('heavy_flow_profile', JSON.stringify(newProfile));
      
      const newSettings: AppSettings = {
        ...settings,
        pin: pin,
        securityEnabled: true
      };
      onUpdateSettings(newSettings);
      
      onLogin(); // Persistent state is handled in App.tsx handleSuccessLogin
      return;
    }

    // Login validation
    const savedProfileStr = localStorage.getItem('heavy_flow_profile');
    const savedSettingsStr = localStorage.getItem('heavy_flow_settings');
    
    if (!savedProfileStr || !savedSettingsStr) {
      setError('No account found. Please register.');
      setMode('signup');
      return;
    }

    const savedProfile: AdminProfile = JSON.parse(savedProfileStr);
    const savedSettings: AppSettings = JSON.parse(savedSettingsStr);

    if (phone === savedProfile.phone && pin === savedSettings.pin) {
      onLogin();
    } else {
      setError(t('invalidLogin'));
    }
  };

  const toggleLanguage = () => {
    const nextLang: LanguageCode = settings.language === 'en' ? 'ta' : 'en';
    onUpdateSettings({ ...settings, language: nextLang });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4 transition-colors">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-xl border border-slate-100 dark:border-slate-800 p-8 space-y-6 animate-in fade-in zoom-in-95 duration-500 overflow-y-auto max-h-[95vh]">
        
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            <div className="bg-amber-500 p-4 rounded-3xl shadow-lg shadow-amber-500/20 text-white flex items-center gap-2">
              <Truck size={32} />
              <div className="w-px h-8 bg-white/20" />
              <HardHat size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white">
            {mode === 'signup' ? t('signUp') : t('login')}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium text-sm">
            {mode === 'signup' ? t('enterDetailsSignup') : t('enterDetailsLogin')}
          </p>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {mode === 'signup' && (
            <>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                  {t('adminName')}
                </label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors">
                    <User size={20} />
                  </div>
                  <input 
                    type="text" 
                    required
                    placeholder={t('adminNamePlaceholder')}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-base"
                    value={adminName}
                    onChange={e => setAdminName(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                  {t('businessName')}
                </label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors">
                    <Building size={20} />
                  </div>
                  <input 
                    type="text" 
                    required
                    placeholder={t('businessNamePlaceholder')}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-base"
                    value={businessName}
                    onChange={e => setBusinessName(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                  {t('address')}
                </label>
                <div className="relative group">
                  <div className="absolute left-4 top-5 text-slate-400 group-focus-within:text-amber-500 transition-colors">
                    <MapPin size={20} />
                  </div>
                  <textarea 
                    placeholder={t('addressPlaceholder')}
                    rows={2}
                    required
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-base resize-none"
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                  />
                </div>
              </div>
            </>
          )}

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
              {t('mobileNumber')}
            </label>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-slate-400 group-focus-within:text-amber-500 transition-colors pointer-events-none">
                <Phone size={20} />
                <span className="text-lg font-bold border-r border-slate-200 dark:border-slate-700 pr-2">+91</span>
              </div>
              <input 
                type="tel" 
                maxLength={10}
                required
                placeholder="**********"
                className="w-full pl-28 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-lg"
                value={phone}
                onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
              {mode === 'signup' ? t('createPin') : t('passwordPin')}
            </label>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors">
                <Lock size={20} />
              </div>
              <input 
                type={showPin ? 'text' : 'password'}
                maxLength={6}
                required
                placeholder="••••"
                className="w-full pl-12 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-lg tracking-[0.2em]"
                value={pin}
                onChange={e => setPin(e.target.value.replace(/\D/g, ''))}
              />
              <button 
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              >
                {showPin ? t('hide') : t('show')}
              </button>
            </div>
          </div>

          {mode === 'signup' && (
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                {t('confirmPin')}
              </label>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors">
                  <CheckCircle size={20} />
                </div>
                <input 
                  type={showPin ? 'text' : 'password'}
                  maxLength={6}
                  required
                  placeholder="••••"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-emerald-500 dark:text-white rounded-2xl outline-none transition-all font-bold text-lg tracking-[0.2em]"
                  value={confirmPin}
                  onChange={e => setConfirmPin(e.target.value.replace(/\D/g, ''))}
                />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 p-3 rounded-xl text-xs font-bold text-center animate-in slide-in-from-top-2">
              {error}
            </div>
          )}

          {mode === 'login' && (
            <div className="flex justify-end px-1">
              <button 
                type="button" 
                onClick={() => setShowForgotModal(true)}
                className="text-xs font-bold text-amber-600 dark:text-amber-500 hover:underline"
              >
                {t('forgotPin')}
              </button>
            </div>
          )}

          <button 
            type="submit"
            className="w-full py-5 bg-amber-500 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-amber-500/20 active:scale-[0.98] transition-all"
          >
            {mode === 'signup' ? t('createAccount') : t('login')}
          </button>
        </form>

        <div className="pt-2 flex flex-col items-center gap-4">
          <button 
            onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
            className="text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-amber-500 transition-colors"
          >
            {mode === 'login' ? t('noAccount') : t('alreadyHaveAccount')}
            <span className="text-amber-500 ml-1 uppercase">{mode === 'login' ? t('signUp') : t('login')}</span>
          </button>

          <button 
            onClick={toggleLanguage}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-600 dark:text-slate-400 font-bold text-xs"
          >
            <Globe size={16} />
            <span>{settings.language === 'en' ? 'Switch to தமிழ்' : 'Switch to English'}</span>
          </button>
        </div>
      </div>

      {showForgotModal && (
        <ForgotPinModal 
          t={t} 
          onBack={() => setShowForgotModal(false)}
          onSuccess={(newPin) => {
            const currentSettings: AppSettings = JSON.parse(localStorage.getItem('heavy_flow_settings') || '{}');
            const updatedSettings = { ...currentSettings, pin: newPin };
            localStorage.setItem('heavy_flow_settings', JSON.stringify(updatedSettings));
            onUpdateSettings(updatedSettings);
            setShowForgotModal(false);
            alert(t('pinResetSuccess'));
          }}
        />
      )}
    </div>
  );
};
