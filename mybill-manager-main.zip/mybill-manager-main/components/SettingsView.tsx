import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Languages, 
  Moon, 
  Sun, 
  Database, 
  ShieldCheck, 
  Download, 
  Lock, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle, 
  KeyRound, 
  X, 
  FileText,
  HelpCircle,
  Phone,
  MessageCircle,
  Mail,
  ChevronDown,
  BellRing,
  UploadCloud,
  DownloadCloud,
  Crown,
  LogOut,
  History
} from 'lucide-react';
import { AppSettings, WorkLog, AdminProfile, LanguageCode, SubscriptionData } from '../types';
import { translations } from '../translations';
import { jsPDF } from 'jspdf';
import { TAMIL_FONT_BASE64 } from '../fonts/tamilFont';
import { ForgotPinModal } from './ForgotPinModal';
import { SubscriptionHistoryView } from './SubscriptionHistoryView';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
  subscription: SubscriptionData | null;
  subscriptionHistory: SubscriptionData[];
  subscriptionStatus: { expired: boolean; warning: boolean };
  onUpdateSubscription: (data: SubscriptionData) => void;
  onLogout: () => void;
  onBack: () => void;
  t: (key: keyof typeof translations['en']) => string;
}

type ProtectedAction = 'backup_menu' | 'pdf' | 'toggle' | 'changePin';

const LANGUAGES: { code: LanguageCode; label: string }[] = [
  { code: 'en', label: 'English' },
  { code: 'ta', label: 'தமிழ்' },
];

const PERSISTENT_BACKUP_KEY = 'HEAVY_FLOW_PERSISTENT_BACKUP';
const SUBSCRIPTION_KEY = 'heavy_flow_subscription';

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, onUpdateSettings, subscription, subscriptionHistory, subscriptionStatus, onUpdateSubscription, onLogout, onBack, t }) => {
  const [showPinDialog, setShowPinDialog] = useState(false);
  const [showVerifyDialog, setShowVerifyDialog] = useState(false);
  const [showForgotPin, setShowForgotPin] = useState(false);
  const [showChangePinDialog, setShowChangePinDialog] = useState(false);
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [showHistoryView, setShowHistoryView] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  
  const [tempPin, setTempPin] = useState('');
  const [verifyPin, setVerifyPin] = useState('');
  const [verifyError, setVerifyError] = useState(false);
  
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [changePinError, setChangePinError] = useState('');

  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [pendingAction, setPendingAction] = useState<ProtectedAction | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentLanguageLabel = LANGUAGES.find(l => l.code === (settings?.language || 'en'))?.label || 'English';

  // Responsive font size helper for Tamil
  const labelTextClass = settings.language === 'ta' ? 'text-sm' : 'text-base';
  const subTextClass = settings.language === 'ta' ? 'text-[9px]' : 'text-[10px]';

  // Support for hardware back button closing modals
  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      if (showBackupModal) {
        setShowBackupModal(false);
        e.preventDefault();
      } else if (showHistoryView) {
        setShowHistoryView(false);
        e.preventDefault();
      } else if (showLogoutConfirm) {
        setShowLogoutConfirm(false);
        e.preventDefault();
      }
    };

    if (showBackupModal || showHistoryView || showLogoutConfirm) {
      window.history.pushState({ modal: 'settings_overlay' }, '');
      window.addEventListener('popstate', handlePopState);
    }

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [showBackupModal, showHistoryView, showLogoutConfirm]);

  const handleDownloadBackup = () => {
    try {
      const data = {
        logs: JSON.parse(localStorage.getItem('heavy_flow_logs') || '[]'),
        profile: JSON.parse(localStorage.getItem('heavy_flow_profile') || '{}'),
        settings: settings,
        app_language: localStorage.getItem('app_language'),
        timestamp: Date.now()
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `heavyflow_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      
      localStorage.setItem(PERSISTENT_BACKUP_KEY, JSON.stringify(data));
      setStatusMsg({ type: 'success', text: t('backupSuccess') });
      setShowBackupModal(false);
    } catch (e) {
      console.error(e);
      setStatusMsg({ type: 'error', text: t('backupError') });
    }
  };

  const handleFileRestore = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);

        if (data.logs) {
          localStorage.setItem('heavy_flow_logs', JSON.stringify(data.logs));
        }
        if (data.profile) {
          localStorage.setItem('heavy_flow_profile', JSON.stringify(data.profile));
        }
        if (data.settings) {
          const currentPin = settings.pin;
          const currentSecurity = settings.securityEnabled;
          const restoredSettings = { 
            ...data.settings, 
            pin: currentPin, 
            securityEnabled: currentSecurity 
          };
          onUpdateSettings(restoredSettings);
        }
        if (data.app_language) {
          localStorage.setItem('app_language', data.app_language);
        }

        setStatusMsg({ type: 'success', text: t('restoreSuccess') || 'Data restored successfully!' });
        setShowBackupModal(false);
        setTimeout(() => window.location.reload(), 1500);
      } catch (err) {
        console.error("Restore error", err);
        setStatusMsg({ type: 'error', text: t('restoreError') || 'Invalid backup file.' });
      }
    };
    reader.readAsText(file);
  };

  const handleFullPdfBackup = () => {
    try {
      const logsStr = localStorage.getItem('heavy_flow_logs') || '[]';
      const logs: WorkLog[] = JSON.parse(logsStr).sort((a: WorkLog, b: WorkLog) => a.timestamp - b.timestamp);
      
      const profileStr = localStorage.getItem('heavy_flow_profile') || '{}';
      const profile: AdminProfile = JSON.parse(profileStr);
      const doc = new jsPDF();
      
      const isTamil = settings.language === 'ta';
      const fontName = isTamil ? 'TamilFont' : 'helvetica';
      
      if (isTamil && TAMIL_FONT_BASE64) {
        try {
          doc.addFileToVFS('TamilFont.ttf', TAMIL_FONT_BASE64);
          doc.addFont('TamilFont.ttf', 'TamilFont', 'normal');
        } catch (e) {
          console.error("Font loading failed", e);
        }
      }

      const setFont = (isBold: boolean = false) => {
        doc.setFont(fontName, isBold && !isTamil ? 'bold' : 'normal');
      };

      let y = 20;
      doc.setFillColor(31, 41, 55);
      doc.rect(0, 0, 210, 45, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      setFont(true);
      doc.text((profile?.businessName || 'MY BILL MANAGER').toUpperCase(), 15, 20);
      doc.setFontSize(10);
      setFont(false);
      doc.text(`${profile?.adminName || 'Owner'} | ${profile?.phone || 'N/A'}`, 15, 28);
      doc.text(profile?.email || '', 15, 33);
      doc.text(profile?.address || '', 15, 38);

      y = 60;
      doc.setTextColor(31, 41, 55);
      doc.setFontSize(14);
      setFont(true);
      doc.text(t('historyReport'), 15, y);
      y += 10;

      logs.forEach((log, index) => {
        if (y > 250) {
          doc.addPage();
          y = 20;
          if (isTamil) doc.setFont('TamilFont');
        }
        doc.setDrawColor(241, 245, 249);
        doc.setFillColor(248, 250, 252);
        doc.rect(10, y, 190, 45, 'F');
        doc.rect(10, y, 190, 45, 'S');
        doc.setFontSize(10);
        doc.setTextColor(31, 41, 55);
        setFont(true);
        doc.text(`${index + 1}. ${log.companyName}`, 15, y + 8);
        setFont(false);
        doc.setTextColor(100, 116, 139);
        doc.setFontSize(8);
        doc.text(`${t('workDate').toUpperCase()}: ${log.workDate} | ${t('vehicle').toUpperCase()}: ${t(log.vehicleType.toLowerCase() as any) || log.vehicleType} | ${t('driver').toUpperCase()}: ${log.driverName}`, 15, y + 14);
        doc.text(`${t('generalLocation').toUpperCase()}: ${log.location} | ${t('time').toUpperCase()}: ${log.startTime} - ${log.endTime}`, 15, y + 19);
        doc.text(`${t('totalHours').toUpperCase()}: ${log.hoursWorked} | ${t('rateHr').toUpperCase()}: ${t('currency')} ${log.hourlyRate}/hr`, 15, y + 24);
        doc.setTextColor(31, 41, 55);
        doc.setFontSize(9);
        setFont(true);
        doc.text(`${t('total').toUpperCase()}: ${t('currency')} ${log.totalAmount.toLocaleString()}`, 15, y + 34);
        doc.text(`${t('paid').toUpperCase()}: ${t('currency')} ${(log.advancePaid + log.paidAmount).toLocaleString()}`, 80, y + 34);
        doc.setTextColor(190, 18, 60);
        doc.text(`${t('balance').toUpperCase().substring(0, 3)}: ${t('currency')} ${log.balanceAmount.toLocaleString()}`, 145, y + 34);
        
        const statusColor = log.status === 'Paid' ? [5, 150, 105] : log.status === 'Partial' ? [217, 119, 6] : [190, 18, 60];
        doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
        doc.text(t(log.status.toLowerCase() as any).toUpperCase(), 175, y + 8);
        y += 50;
      });

      const totalRevenueValue = logs.reduce((s, l) => s + (l.totalAmount || 0), 0);
      const totalPaidValue = logs.reduce((s, l) => s + ((l.advancePaid || 0) + (l.paidAmount || 0)), 0);
      const totalBalanceValue = logs.reduce((s, l) => s + (l.balanceAmount || 0), 0);
      const totalClientsCount = new Set(logs.map(l => l.companyName)).size;

      if (y > 220) { doc.addPage(); y = 20; if (isTamil) doc.setFont('TamilFont'); }
      y += 10;
      doc.setDrawColor(31, 41, 55);
      doc.setLineWidth(0.5);
      doc.line(10, y, 200, y);
      y += 10;
      doc.setTextColor(31, 41, 55);
      setFont(true);
      doc.text(t('consolidatedSummary'), 15, y);
      y += 10;
      setFont(false);
      doc.text(`${t('totalRecords')}: ${logs.length}`, 15, y);
      doc.text(`${t('totalClients')}: ${totalClientsCount}`, 15, y + 6);
      doc.text(`${t('totalRevenue')}:`, 130, y);
      doc.text(`${t('currency')} ${totalRevenueValue.toLocaleString()}`, 175, y, { align: 'right' });
      doc.text(`${t('totalPaid')}:`, 130, y + 6);
      doc.text(`${t('currency')} ${totalPaidValue.toLocaleString()}`, 175, y + 6, { align: 'right' });
      y += 12;
      setFont(true);
      doc.text(`${t('totalBalanceDue')}:`, 130, y);
      doc.setTextColor(190, 18, 60);
      doc.text(`${t('currency')} ${totalBalanceValue.toLocaleString()}`, 175, y, { align: 'right' });
      doc.setTextColor(148, 163, 184);
      doc.setFontSize(8);
      setFont(false);
      const backupDate = new Date().toLocaleDateString(isTamil ? 'ta-IN' : 'en-GB');
      doc.text(`${t('generatedOn')} ${backupDate}`, 105, 285, { align: 'center' });
      doc.save(`heavyflow_full_backup_${backupDate.replace(/\//g, '-')}.pdf`);
      setStatusMsg({ type: 'success', text: t('pdfSuccess') });
    } catch (e) {
      console.error(e);
      setStatusMsg({ type: 'error', text: t('pdfError') });
    }
  };

  const handleProtectedAction = (action: ProtectedAction) => {
    if (!settings.securityEnabled) {
      executeAction(action);
    } else {
      setPendingAction(action);
      setShowVerifyDialog(true);
    }
  };

  const executeAction = (action: ProtectedAction) => {
    if (action === 'backup_menu') setShowBackupModal(true);
    else if (action === 'pdf') handleFullPdfBackup();
    else if (action === 'toggle') onUpdateSettings({ ...settings, securityEnabled: !settings.securityEnabled });
    else if (action === 'changePin') setShowChangePinDialog(true);
  };

  const handleVerifyPin = () => {
    if (verifyPin === settings.pin) {
      if (pendingAction) {
        executeAction(pendingAction);
        setPendingAction(null);
      }
      setShowVerifyDialog(false);
      setVerifyPin('');
      setVerifyError(false);
    } else {
      setVerifyError(true);
      setVerifyPin('');
    }
  };

  const handleSetPin = () => {
    if (tempPin.length >= 4) {
      onUpdateSettings({ ...settings, pin: tempPin, securityEnabled: true });
      setShowPinDialog(false);
      setTempPin('');
    }
  };

  const handleChangePin = () => {
    if (oldPin !== settings.pin) { setChangePinError(t('wrongPin')); return; }
    if (newPin.length < 4) { setChangePinError('PIN must be 4-6 digits'); return; }
    if (newPin !== confirmPin) { setChangePinError('PINs do not match'); return; }
    onUpdateSettings({ ...settings, pin: newPin });
    setShowChangePinDialog(false);
    setOldPin(''); setNewPin(''); setConfirmPin(''); setChangePinError('');
    setStatusMsg({ type: 'success', text: 'Security PIN updated!' });
  };

  const handleSecurityToggle = () => {
    if (settings.securityEnabled) handleProtectedAction('toggle');
    else if (settings.pin) onUpdateSettings({ ...settings, securityEnabled: true });
    else setShowPinDialog(true);
  };

  const closeBackupModal = () => {
    setShowBackupModal(false);
  };

  const handleRenewNow = () => {
    const now = Date.now();
    const expiredSub = { ...subscription!, endDate: now - 1000 };
    onUpdateSubscription(expiredSub);
    localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(expiredSub));
  };

  if (showHistoryView) {
    return <SubscriptionHistoryView history={subscriptionHistory} onBack={() => setShowHistoryView(false)} t={t} />;
  }

  return (
    <div className="fixed inset-0 bg-slate-50 z-[70] overflow-y-auto pb-32 dark:bg-slate-950 transition-colors">
      <div className="bg-white border-b border-slate-100 sticky top-0 z-10 px-4 py-3 flex items-center space-x-4 dark:bg-slate-800 dark:border-slate-700">
        <button onClick={onBack} className="p-1.5 hover:bg-slate-50 rounded-full dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-bold dark:text-white">{t('settings')}</h1>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-4">
        {statusMsg && (
          <div className={`p-3 rounded-xl flex items-center gap-3 ${statusMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
            {statusMsg.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
            <span className="font-bold text-xs">{statusMsg.text}</span>
            <button onClick={() => setStatusMsg(null)} className="ml-auto"><X size={12} /></button>
          </div>
        )}

        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm dark:bg-slate-800 dark:border-slate-700 overflow-hidden transition-all">
          <button onClick={() => setIsLanguageOpen(!isLanguageOpen)} className="w-full p-4 flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="bg-blue-50 p-2 rounded-xl text-blue-600 dark:bg-blue-900/30 flex-shrink-0"><Languages size={20} /></div>
              <div className="text-left min-w-0">
                <span className={`${labelTextClass} font-bold dark:text-white block truncate break-words`}>{t('language')}</span>
                <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest truncate">{currentLanguageLabel}</span>
              </div>
            </div>
            <ChevronDown className={`text-slate-400 flex-shrink-0 transition-transform ${isLanguageOpen ? 'rotate-180' : ''}`} size={20} />
          </button>
          {isLanguageOpen && (
            <div className="px-4 pb-4 grid grid-cols-2 gap-2 animate-in slide-in-from-top-2 duration-200">
              {LANGUAGES.map((lang) => (
                <button 
                  key={lang.code} 
                  onClick={() => onUpdateSettings({ ...settings, language: lang.code })} 
                  className={`py-3 text-[11px] font-bold rounded-xl border transition-all ${settings.language === lang.code ? 'bg-amber-500 border-amber-500 text-white shadow-md' : 'bg-slate-50 text-slate-500 dark:bg-slate-900 dark:border-slate-700'}`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-4 dark:bg-slate-800 dark:border-slate-700 flex items-center justify-between transition-all">
          <div className="flex items-center gap-3 min-w-0">
            <div className="bg-amber-50 p-2 rounded-xl text-amber-600 dark:bg-amber-900/30 flex-shrink-0">
              {settings.theme === 'light' ? <Sun size={20} /> : <Moon size={20} />}
            </div>
            <span className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>{t('theme')}</span>
          </div>
          <div className="flex bg-slate-100 p-1 rounded-xl dark:bg-slate-700 flex-shrink-0">
            <button onClick={() => onUpdateSettings({ ...settings, theme: 'light' })} className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${settings.theme === 'light' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-500'}`}>{t('light')}</button>
            <button onClick={() => onUpdateSettings({ ...settings, theme: 'dark' })} className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${settings.theme === 'dark' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-500'}`}>{t('dark')}</button>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm dark:bg-slate-800 dark:border-slate-700 overflow-hidden transition-all">
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="bg-emerald-50 p-2 rounded-xl text-emerald-600 dark:bg-blue-900/30 flex-shrink-0">
                <ShieldCheck size={20} />
              </div>
              <div className="min-w-0">
                <p className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>{t('security')}</p>
                <p className={`${subTextClass} text-slate-400 font-bold uppercase tracking-wide truncate`}>{t('billEditProtected')}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
              <input type="checkbox" className="sr-only peer" checked={settings.securityEnabled} onChange={handleSecurityToggle} />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:bg-amber-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-full shadow-inner"></div>
            </label>
          </div>
          {settings.securityEnabled && (
            <button 
              onClick={() => handleProtectedAction('changePin')} 
              className="w-full px-4 py-4 bg-slate-50/50 border-t flex items-center justify-between dark:bg-slate-900/30 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <div className="flex items-center gap-2">
                <KeyRound size={16} className="text-amber-500" />
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">{t('changeSecurityPin')}</span>
              </div>
              <ChevronRight size={16} className="text-slate-300" />
            </button>
          )}
        </div>

        {/* Subscription Status Card */}
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-4 dark:bg-slate-800 dark:border-slate-700 flex items-center justify-between transition-all">
          <div className="flex items-center gap-3 min-w-0">
            <div className="bg-amber-100 p-3 rounded-2xl text-amber-600 dark:bg-amber-900/30 flex-shrink-0">
              <Crown size={20} />
            </div>
            <div className="min-w-0">
              <p className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>
                {subscription?.planType === 'free' ? t('freeTrialActive') : t('subscriptionActive')}
              </p>
              <p className={`${subTextClass} text-slate-400 font-bold uppercase tracking-wide truncate`}>
                {t('subscriptionExpiresOn')}: {new Date(subscription?.endDate || 0).toLocaleDateString()}
              </p>
            </div>
          </div>
          {subscriptionStatus.warning && (
            <button 
              onClick={handleRenewNow}
              className="px-3 py-1.5 bg-amber-500 text-white rounded-xl font-black text-[9px] uppercase shadow-lg shadow-amber-500/20 active:scale-95 whitespace-nowrap flex-shrink-0 ml-2"
            >
              Renew
            </button>
          )}
        </div>

        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm dark:bg-slate-800 dark:border-slate-700 overflow-hidden transition-all">
          <button onClick={() => handleProtectedAction('backup_menu')} className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
            <div className="bg-indigo-50 p-2 rounded-xl text-indigo-600 dark:bg-indigo-900/30 flex-shrink-0"><Database size={20} /></div>
            <div className="text-left min-w-0"><p className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>{t('backup')}</p></div>
            <ChevronRight size={20} className="ml-auto text-slate-300 flex-shrink-0" />
          </button>
          <div className="h-px bg-slate-50 mx-4 dark:bg-slate-700" />
          <button onClick={() => handleProtectedAction('pdf')} className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
            <div className="bg-amber-50 p-2 rounded-xl text-amber-600 dark:bg-amber-900/30 flex-shrink-0"><FileText size={20} /></div>
            <div className="text-left min-w-0"><p className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>{t('fullPdfReport')}</p><p className={`${subTextClass} text-slate-400 font-bold uppercase truncate`}>{t('fullPdfReportSub')}</p></div>
            <ChevronRight size={20} className="ml-auto text-slate-300 flex-shrink-0" />
          </button>
          <div className="h-px bg-slate-50 mx-4 dark:bg-slate-700" />
          <button onClick={() => setShowHistoryView(true)} className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
            <div className="bg-blue-50 p-2 rounded-xl text-blue-600 dark:bg-blue-900/30 flex-shrink-0"><History size={20} /></div>
            <div className="text-left min-w-0"><p className={`${labelTextClass} font-bold dark:text-white truncate break-words`}>{t('subscriptionHistory')}</p></div>
            <ChevronRight size={20} className="ml-auto text-slate-300 flex-shrink-0" />
          </button>
          <div className="h-px bg-slate-50 mx-4 dark:bg-slate-700" />
          <button onClick={() => setShowLogoutConfirm(true)} className="w-full p-4 flex items-center gap-3 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors">
            <div className="bg-rose-50 p-2 rounded-xl text-rose-600 dark:bg-rose-900/30 flex-shrink-0"><LogOut size={20} /></div>
            <div className="text-left min-w-0"><p className={`${labelTextClass} font-bold text-rose-600 dark:text-rose-400 truncate break-words`}>{t('logout')}</p></div>
            <ChevronRight size={20} className="ml-auto text-rose-300 flex-shrink-0" />
          </button>
        </div>

        <button onClick={onBack} className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl active:scale-[0.98] transition-all dark:bg-black">{t('done')}</button>
      </div>

      {showBackupModal && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col dark:bg-slate-900 transition-all animate-in slide-in-from-bottom duration-300 relative max-h-[90vh]">
            <div className="bg-white border-b sticky top-0 z-10 px-4 py-4 flex items-center space-x-4 dark:bg-slate-900 dark:border-slate-800 rounded-t-3xl">
              <button onClick={closeBackupModal} className="p-2 hover:bg-slate-50 rounded-full dark:hover:bg-slate-800 transition-colors dark:text-slate-300">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h1 className="text-lg font-bold dark:text-white">{t('backup')}</h1>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto pb-32">
              <div className="text-center">
                <div className="bg-indigo-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-indigo-900/20"><Database className="text-indigo-600" size={32} /></div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 font-medium px-4">
                  Use this to keep your data safe before uninstalling the app.
                </p>
              </div>
              <div className="space-y-3">
                <button 
                  onClick={handleDownloadBackup} 
                  className="w-full p-5 bg-white border-2 border-slate-100 rounded-2xl flex items-center gap-4 hover:border-amber-500 transition-all dark:bg-slate-800 dark:border-slate-700"
                >
                  <div className="bg-amber-500 p-2 rounded-xl text-white flex-shrink-0"><DownloadCloud size={20} /></div>
                  <div className="text-left min-w-0"><p className="text-sm font-bold dark:text-white truncate">Download All Data</p><p className="text-[10px] text-slate-400 font-bold uppercase truncate">Export history & settings</p></div>
                </button>

                <button 
                  onClick={() => fileInputRef.current?.click()} 
                  className="w-full p-5 bg-white border-2 border-slate-100 rounded-2xl flex items-center gap-4 hover:border-emerald-500 transition-all dark:bg-slate-800 dark:border-slate-700"
                >
                  <div className="bg-emerald-500 p-2 rounded-xl text-white flex-shrink-0"><UploadCloud size={20} /></div>
                  <div className="text-left min-w-0"><p className="text-sm font-bold dark:text-white truncate">Restore All Data</p><p className="text-[10px] text-slate-400 font-bold uppercase truncate">Import from previous backup</p></div>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept=".json" 
                    onChange={handleFileRestore}
                  />
                </button>
              </div>
              <button onClick={closeBackupModal} className="w-full py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300">
                {t('close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {showLogoutConfirm && (
        <div className="fixed inset-0 z-[500] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-8 shadow-2xl space-y-6 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
            <div className="text-center">
              <div className="bg-rose-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 dark:bg-rose-900/20">
                <LogOut className="text-rose-500" size={40} />
              </div>
              <h2 className="text-2xl font-black dark:text-white">{t('logout')}</h2>
              <p className="text-slate-500 dark:text-slate-400 font-medium mt-2 break-words">{t('logoutConfirm')}</p>
            </div>
            <div className="flex flex-col gap-3">
              <button 
                onClick={onLogout} 
                className="w-full py-4 bg-rose-500 text-white rounded-2xl font-black shadow-lg shadow-rose-500/20 active:scale-95 transition-all truncate"
              >
                {t('logoutYes')}
              </button>
              <button 
                onClick={() => setShowLogoutConfirm(false)} 
                className="w-full py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300 active:scale-95 transition-all truncate"
              >
                {t('logoutNo')}
              </button>
            </div>
          </div>
        </div>
      )}

      {showPinDialog && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-6 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
            <div className="text-center"><div className="bg-emerald-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-emerald-900/20"><Lock className="text-emerald-500" size={32} /></div><h2 className="text-xl font-bold dark:text-white">{t('setPin')}</h2><p className="text-sm text-slate-500 dark:text-slate-400">Enter a 4-6 digit code</p></div>
            <input type="password" inputMode="numeric" maxLength={6} autoFocus className="w-full p-5 bg-slate-50 border rounded-2xl text-center text-3xl font-black tracking-[0.5em] outline-none dark:bg-slate-800 dark:text-white focus:border-emerald-500" value={tempPin} onChange={e => setTempPin(e.target.value.replace(/\D/g, ''))} />
            <div className="flex gap-3"><button onClick={() => setShowPinDialog(false)} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300">{t('cancel')}</button><button onClick={handleSetPin} className="flex-1 py-4 bg-emerald-500 text-white rounded-2xl font-bold">{t('setPin')}</button></div>
          </div>
        </div>
      )}

      {showChangePinDialog && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-4 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
            <div className="text-center"><div className="bg-amber-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 dark:bg-amber-900/20"><KeyRound className="text-amber-500" size={24} /></div><h2 className="text-lg font-bold dark:text-white">{t('changeSecurityPin')}</h2></div>
            <div className="space-y-3">
              <input type="password" inputMode="numeric" maxLength={6} className="w-full p-3 bg-slate-50 border rounded-xl text-center text-xl font-bold dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500" value={oldPin} onChange={e => setOldPin(e.target.value.replace(/\D/g, ''))} placeholder={t('oldPin')} />
              <input type="password" inputMode="numeric" maxLength={6} className="w-full p-3 bg-slate-50 border rounded-xl text-center text-xl font-bold dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500" value={newPin} onChange={e => setNewPin(e.target.value.replace(/\D/g, ''))} placeholder={t('newPin')} />
              <input type="password" inputMode="numeric" maxLength={6} className="w-full p-3 bg-slate-50 border rounded-xl text-center text-xl font-bold dark:bg-slate-800 dark:text-white outline-none focus:border-amber-500" value={confirmPin} onChange={e => setConfirmPin(e.target.value.replace(/\D/g, ''))} placeholder={t('confirmNewPin')} />
            </div>
            {changePinError && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{changePinError}</p>}
            <div className="flex gap-2"><button onClick={() => setShowChangePinDialog(false)} className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold dark:bg-slate-800 dark:text-slate-300">{t('cancel')}</button><button onClick={handleChangePin} className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold shadow-lg shadow-amber-500/20">{t('updatePin')}</button></div>
          </div>
        </div>
      )}

      {showVerifyDialog && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-sm rounded-3xl p-6 shadow-2xl space-y-6 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
            <div className="text-center"><div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-amber-900/20"><Lock className="text-amber-500" size={32} /></div><h2 className="text-xl font-bold dark:text-white">{t('enterPin')}</h2><p className="text-sm text-slate-500 dark:text-slate-400">{t('verifyPinSub')}</p></div>
            <input type="password" inputMode="numeric" maxLength={6} autoFocus className={`w-full p-5 bg-slate-50 border rounded-2xl text-center text-3xl font-black tracking-[0.5em] outline-none dark:bg-slate-800 dark:text-white transition-all ${verifyError ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-slate-200 focus:border-amber-500'}`} placeholder="••••" value={verifyPin} onChange={e => {setVerifyPin(e.target.value.replace(/\D/g, '')); setVerifyError(false);}} />
            {verifyError && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{verifyError === true ? t('incorrectPin') : verifyError}</p>}
            <div className="flex justify-end px-1">
              <button 
                type="button" 
                onClick={() => { setShowVerifyDialog(false); setShowForgotPin(true); }}
                className="text-xs font-bold text-amber-600 dark:text-amber-500 hover:underline"
              >
                {t('forgotPin')}
              </button>
            </div>
            <div className="flex gap-3"><button onClick={() => {setShowVerifyDialog(false); setVerifyPin(''); setVerifyError(false);}} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300">{t('cancel')}</button><button onClick={handleVerifyPin} className="flex-1 py-4 bg-amber-500 text-white rounded-2xl font-bold shadow-lg shadow-amber-500/20">Verify</button></div>
          </div>
        </div>
      )}

      {showForgotPin && (
        <ForgotPinModal 
          t={t} 
          onBack={() => setShowForgotPin(false)}
          onSuccess={(newPin) => {
            const currentSettings = JSON.parse(localStorage.getItem('heavy_flow_settings') || '{}');
            const updatedSettings = { ...currentSettings, pin: newPin };
            localStorage.setItem('heavy_flow_settings', JSON.stringify(updatedSettings));
            onUpdateSettings(updatedSettings);
            setShowForgotPin(false);
            alert(t('pinResetSuccess'));
          }}
        />
      )}
    </div>
  );
};