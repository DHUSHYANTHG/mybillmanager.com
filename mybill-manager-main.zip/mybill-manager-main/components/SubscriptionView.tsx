import React, { useState } from 'react';
import { Check, Crown, Star, ShieldCheck, Zap, ArrowRight, Loader2 } from 'lucide-react';
import { translations } from '../translations';
import { SubscriptionData } from '../types';

interface SubscriptionViewProps {
  onPlanActivated: (data: SubscriptionData) => void;
  t: (key: keyof typeof translations['en']) => string;
}

const PLANS = [
  { id: '1month', months: 1, price: 15, label: 'planMonth' },
  { id: '3months', months: 3, price: 45, label: 'planQuarter' },
  { id: '6months', months: 6, price: 90, label: 'planHalfYear' },
  { id: '1year', months: 12, price: 120, label: 'planYear', bestValue: true },
];

const PAYMENT_METHODS = ['UPI', 'Google Pay', 'PhonePe', 'Card', 'Cash'];

export const SubscriptionView: React.FC<SubscriptionViewProps> = ({ onPlanActivated, t }) => {
  const [selectedPlan, setSelectedPlan] = useState(PLANS[3]); // Default to 1 Year
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayment = () => {
    setIsProcessing(true);
    // Simulate payment gateway delay
    setTimeout(() => {
      const now = Date.now();
      const expiryDate = new Date();
      expiryDate.setMonth(expiryDate.getMonth() + selectedPlan.months);
      
      const subData: SubscriptionData = {
        planType: selectedPlan.id as any,
        startDate: now,
        endDate: expiryDate.getTime(),
        isActive: true,
        paymentId: `PAY-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        amount: selectedPlan.price,
        paymentMethod: PAYMENT_METHODS[Math.floor(Math.random() * PAYMENT_METHODS.length)]
      };
      
      onPlanActivated(subData);
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[1000] bg-white dark:bg-slate-950 overflow-y-auto pb-12 transition-colors">
      <div className="max-w-2xl mx-auto px-4 pt-12 text-center space-y-6">
        <div className="flex justify-center">
          <div className="bg-amber-100 p-6 rounded-full dark:bg-amber-900/30">
            <Crown size={48} className="text-amber-500 animate-bounce" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-black text-slate-900 dark:text-white leading-tight">
            {t('subscriptionTitle')}
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium px-4 max-w-md mx-auto">
            {t('subscriptionSub')}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 mt-8">
          {PLANS.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlan(plan)}
              className={`relative p-6 rounded-3xl border-2 text-left transition-all ${
                selectedPlan.id === plan.id 
                ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-900/20' 
                : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-200'
              }`}
            >
              {plan.bestValue && (
                <div className="absolute top-0 right-6 -translate-y-1/2 bg-amber-500 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg">
                  {t('bestValue')}
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${selectedPlan.id === plan.id ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-400 dark:bg-slate-800'}`}>
                    {plan.months === 12 ? <Zap size={24} /> : <Star size={24} />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">{t(plan.label as any)}</h3>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                      ₹{(plan.price / plan.months).toFixed(0)} {t('perMonth')}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-slate-900 dark:text-white">₹{plan.price}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{t('totalPrice')}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="pt-8 space-y-4">
          <div className="flex items-center justify-center gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">
            <div className="flex items-center gap-1"><ShieldCheck size={14} className="text-emerald-500" /> Secure Payment</div>
            <div className="w-1 h-1 bg-slate-300 rounded-full" />
            <div className="flex items-center gap-1"><Check size={14} className="text-emerald-500" /> Instant Access</div>
          </div>
          
          <button 
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full py-5 bg-amber-500 text-white rounded-[2rem] font-black text-lg shadow-xl shadow-amber-500/30 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:scale-100"
          >
            {isProcessing ? (
              <>
                <Loader2 className="animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <span>{t('proceedToPay')}</span>
                <ArrowRight size={24} />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};