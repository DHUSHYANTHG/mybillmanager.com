import React, { useMemo } from 'react';
import { ArrowLeft, History, HardHat, Truck, ChevronRight, Wallet, Clock, FileText } from 'lucide-react';
import { WorkLog, VehicleType, AppSettings } from '../types';
import { translations } from '../translations';

interface ClientBillsProps {
  clientName: string;
  logs: WorkLog[];
  onBack: () => void;
  onSelectLog: (log: WorkLog) => void;
  settings: AppSettings;
  t: (key: keyof typeof translations['en']) => string;
}

export const ClientBills: React.FC<ClientBillsProps> = ({ clientName, logs, onBack, onSelectLog, settings, t }) => {
  const clientLogs = useMemo(() => {
    return logs
      .filter(l => l.companyName.trim().toLowerCase() === clientName.trim().toLowerCase())
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [logs, clientName]);

  const clientStats = useMemo(() => {
    const total = clientLogs.reduce((s, l) => s + l.totalAmount, 0);
    const paid = clientLogs.reduce((s, l) => s + (l.advancePaid + l.paidAmount), 0);
    const balance = total - paid;
    return { total, paid, balance };
  }, [clientLogs]);

  return (
    <div className="fixed inset-0 bg-slate-50 z-[90] overflow-y-auto pb-32 dark:bg-slate-950 transition-colors">
      <div className="bg-white border-b sticky top-0 z-10 px-4 py-4 flex items-center space-x-4 dark:bg-slate-900 dark:border-slate-800 transition-colors">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-600 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"><ArrowLeft className="w-6 h-6" /></button>
        <div className="min-w-0"><h1 className="text-xl font-bold text-slate-900 truncate dark:text-white">{t('bills')}: {clientName}</h1><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{clientLogs.length} {t('recordsFound')}</p></div>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-6">
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white p-4 rounded-3xl border border-slate-100 dark:bg-slate-900 dark:border-slate-800 shadow-sm"><p className="text-[8px] font-black text-slate-400 uppercase mb-1">{t('total')}</p><p className="text-xs font-black dark:text-white">₹{clientStats.total.toLocaleString()}</p></div>
          <div className="bg-white p-4 rounded-3xl border border-slate-100 dark:bg-slate-900 dark:border-slate-800 shadow-sm"><p className="text-[8px] font-black text-slate-400 uppercase mb-1">{t('paid')}</p><p className="text-xs font-black text-emerald-600 dark:text-emerald-400">₹{clientStats.paid.toLocaleString()}</p></div>
          <div className="bg-white p-4 rounded-3xl border border-slate-100 dark:bg-slate-900 dark:border-slate-800 shadow-sm"><p className="text-[8px] font-black text-slate-400 uppercase mb-1">{t('balance')}</p><p className="text-xs font-black text-rose-600 dark:text-rose-400">₹{clientStats.balance.toLocaleString()}</p></div>
        </div>

        <div className="space-y-3">
          {clientLogs.length > 0 ? (
            clientLogs.map(log => (
              <button key={log.id} onClick={() => onSelectLog(log)} className="w-full text-left bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm hover:border-amber-200 dark:bg-slate-900 dark:border-slate-800 dark:hover:border-amber-900 transition-all flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-xl ${log.vehicleType === VehicleType.BACKHOE ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/30' : 'bg-blue-50 text-blue-600 dark:bg-blue-900/30'}`}>
                    {log.vehicleType === VehicleType.BACKHOE ? <HardHat size={20} /> : <Truck size={20} />}
                  </div>
                  <div><h4 className="font-bold text-slate-900 text-sm dark:text-white">{log.workDate}</h4><p className="text-[10px] font-bold text-slate-400 uppercase dark:text-slate-500">{log.location}</p></div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-black text-slate-900 dark:text-white flex items-center justify-end">₹{log.totalAmount.toLocaleString()}<ChevronRight className="ml-2 w-4 h-4" /></div>
                  <div className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase mt-1 inline-block ${log.status === 'Paid' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' : log.status === 'Partial' ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-rose-50 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400'}`}>{t(log.status.toLowerCase() as any)}</div>
                </div>
              </button>
            ))
          ) : (
            <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed dark:bg-slate-900 dark:border-slate-800"><p className="text-slate-400 font-bold text-sm">{t('noBillsFound')}</p></div>
          )}
        </div>

        <button onClick={onBack} className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-bold text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 transition-all mt-4 dark:bg-black">{t('backToDirectory')}</button>
      </div>
    </div>
  );
};