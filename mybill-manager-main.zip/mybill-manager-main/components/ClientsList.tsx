import React, { useState, useMemo } from 'react';
import { ArrowLeft, User, Phone, MapPin, Search, Users, ChevronRight } from 'lucide-react';
import { WorkLog, AppSettings } from '../types';
import { ClientBills } from './ClientBills';
import { translations } from '../translations';

interface ClientsListProps {
  logs: WorkLog[];
  onBack: () => void;
  onSelectLog: (log: WorkLog) => void;
  settings: AppSettings;
  t: (key: keyof typeof translations['en']) => string;
}

export const ClientsList: React.FC<ClientsListProps> = ({ logs, onBack, onSelectLog, settings, t }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingClient, setViewingClient] = useState<string | null>(null);

  const clients = useMemo(() => {
    const clientMap = new Map();
    [...logs].sort((a, b) => b.timestamp - a.timestamp).forEach(log => {
      const name = log.companyName.trim();
      if (name && !clientMap.has(name)) {
        clientMap.set(name, {
          name: name,
          phone: log.clientPhone || t('notAvailable'),
          location: log.location,
          lastWorkDate: log.workDate
        });
      }
    });

    return Array.from(clientMap.values())
      .filter(client => 
        client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        client.phone.includes(searchTerm) ||
        client.location.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [logs, searchTerm, t]);

  if (viewingClient) {
    return (
      <ClientBills 
        clientName={viewingClient} 
        logs={logs} 
        onBack={() => setViewingClient(null)} 
        onSelectLog={onSelectLog}
        settings={settings}
        t={t}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-slate-50 z-[80] overflow-y-auto pb-32 dark:bg-slate-950 transition-colors">
      <div className="bg-white border-b sticky top-0 z-10 px-4 py-4 flex items-center justify-between dark:bg-slate-900 dark:border-slate-800 transition-colors">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-600 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors active:scale-90"><ArrowLeft className="w-6 h-6" /></button>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">{t('clientDirectory')}</h1>
        </div>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-6">
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-[2.5rem] p-8 text-white shadow-xl relative overflow-hidden dark:shadow-none">
          <Users size={120} className="absolute -right-8 -bottom-8 opacity-10" />
          <div className="relative z-10">
            <p className="text-amber-100 text-[10px] font-black uppercase tracking-[0.2em]">{t('partnerNetwork')}</p>
            <h2 className="text-5xl font-black mt-2 tracking-tighter">{clients.length}</h2>
            <p className="text-amber-100/80 text-xs mt-1 font-medium italic">{t('uniqueClients')}</p>
          </div>
        </div>

        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500" size={18} />
          <input type="text" placeholder={t('searchPlaceholder')} className="w-full pl-12 pr-4 py-5 bg-white border border-slate-200 rounded-[2rem] shadow-sm outline-none transition-all font-semibold text-slate-700 dark:bg-slate-900 dark:border-slate-800 dark:text-white" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>

        <div className="space-y-4">
          {clients.length > 0 ? (
            clients.map((client, idx) => (
              <div key={idx} onClick={() => setViewingClient(client.name)} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center space-x-5 transition-all active:scale-[0.98] cursor-pointer dark:bg-slate-900 dark:border-slate-800 dark:hover:border-amber-900">
                <div className="bg-slate-50 dark:bg-slate-800 w-16 h-16 rounded-2xl flex items-center justify-center text-amber-500 shrink-0"><User size={28} /></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1"><h3 className="font-black text-slate-900 truncate text-lg tracking-tight dark:text-white">{client.name}</h3><ChevronRight className="text-slate-300 w-5 h-5" /></div>
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center text-slate-500 text-sm font-bold gap-2 dark:text-slate-400"><div className="w-6 h-6 rounded-lg bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 dark:text-amber-400"><Phone size={14} /></div><span>{client.phone}</span></div>
                    <div className="flex items-center text-slate-400 text-xs font-bold gap-2 uppercase tracking-wide dark:text-slate-500"><div className="w-6 h-6 rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center"><MapPin size={14} /></div><span className="truncate">{client.location}</span></div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-24 bg-white rounded-[3rem] border border-dashed dark:bg-slate-900 dark:border-slate-800"><h3 className="text-lg font-black text-slate-900 mb-2 dark:text-white">{t('noClientsFound')}</h3></div>
          )}
        </div>

        <button onClick={onBack} className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl active:scale-95 transition-all dark:bg-black">{t('returnToDashboard')}</button>
      </div>
    </div>
  );
};