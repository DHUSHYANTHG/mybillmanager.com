
import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  onClick?: () => void;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, icon, color, onClick }) => {
  const valueStr = String(value);
  const hasCurrency = valueStr.startsWith('₹');
  const displaySymbol = hasCurrency ? '₹' : '';
  const displayValue = hasCurrency ? valueStr.substring(1) : valueStr;

  return (
    <div 
      onClick={onClick}
      className={`bg-white py-10 px-4 sm:py-12 sm:px-6 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-center space-x-3 sm:space-x-5 min-w-0 transition-all active:scale-[0.96] min-h-[150px] sm:min-h-[180px] dark:bg-slate-900 dark:border-slate-800 transition-colors ${onClick ? 'cursor-pointer hover:border-amber-200 hover:shadow-md dark:hover:border-amber-900' : ''}`}
    >
      <div className={`p-3.5 sm:p-4 rounded-2xl flex-shrink-0 ${color} flex items-center justify-center [&>svg]:!w-7 [&>svg]:!h-7 sm:[&>svg]:!w-8 sm:[&>svg]:!h-8 transition-colors`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest truncate">
          {title}
        </p>
        <div 
          className="font-black text-slate-900 truncate flex items-baseline dark:text-white"
          style={{ 
            fontSize: 'clamp(1.1rem, 4vw, 1.5rem)',
            lineHeight: '1.2'
          }}
        >
          {displaySymbol && (
            <span className="text-[0.7em] font-bold mr-0.5 text-slate-500 dark:text-slate-400">{displaySymbol}</span>
          )}
          <span className="tabular-nums tracking-tight">
            {displayValue}
          </span>
        </div>
      </div>
    </div>
  );
};
