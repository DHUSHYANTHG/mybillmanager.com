import React from 'react';
import { ArrowLeft, Crown, Clock, Calendar, Wallet, CheckCircle2, History } from 'lucide-react';
import { SubscriptionData } from '../types';
import { translations } from '../translations';

interface SubscriptionHistoryViewProps {
  history: SubscriptionData[];
  onBack: () => void;
  t: (key: keyof typeof translations['en']) => string;
}

export const SubscriptionHistoryView: React.FC<SubscriptionHistoryViewProps> = ({ history, onBack, t }) => {
  const getPlanLabel = (type: string) => {
    if (type === 'free') return t('freeTrial');
    const plans: any = {
      '1month': t('planMonth'),
      '3months': t('planQuarter'),
      '6months': t('planHalfYear'),
      '1year': t('planYear')
    };
    return plans[type] || type;
  };

  const isPlanActive = (sub: SubscriptionData) => {
    return Date.now() >= sub.startDate && Date.now() <= sub.endDate;
  };

  return (
    <div className="fixed inset-0 z-[110] bg-slate-50 dark:bg-slate-950 overflow-y-auto pb-32 transition-colors">
      <div className="bg-white border-b border-slate-100 sticky top-0 z-10 px-4 py-3 flex items-center space-x-4 dark:bg-slate-800 dark:border-slate-700">
        <button onClick={onBack} className="p-1.5 hover:bg-slate-50 rounded-full dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-bold dark:text-white">{t('subscriptionHistory')}</h1>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-4">
        {history.length > 0 ? (
          history.map((sub, idx) => {
            const active = isPlanActive(sub);
            return (
              <div 
                key={idx} 
                className={`bg-white rounded-3xl border shadow-sm p-6 space-y-4 dark:bg-slate-900 transition-all ${active ? 'border-emerald-500/30' : 'border-slate-100 dark:border-slate-800 opacity-80'}`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-2xl ${active ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/30' : 'bg-slate-100 text-slate-400 dark:bg-slate-800'}`}>
                      <Crown size={24} />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white">{getPlanLabel(sub.planType)}</h3>
                      <div className={`mt-1 inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest ${active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                        {active ? t('active') : t('expired')}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-slate-900 dark:text-white">₹{sub.amount ?? 0}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('amountPaid')}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-4 border-y border-slate-50 dark:border-slate-800">
                  <div className="space-y-1">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{t('startDate')}</p>
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                      <Calendar size={14} className="text-slate-400" />
                      {new Date(sub.startDate).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{t('endDate')}</p>
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                      <Clock size={14} className="text-slate-400" />
                      {new Date(sub.endDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex justify-between items-center text-[10px] font-bold">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <Wallet size={14} />
                    <span className="uppercase tracking-widest">{t('paymentMethod')}: {sub.paymentMethod || 'N/A'}</span>
                  </div>
                  {sub.paymentId && (
                    <div className="text-slate-400 font-mono">
                      ID: {sub.paymentId}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-24 text-center space-y-4 opacity-50">
            <div className="bg-slate-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto dark:bg-slate-800">
              <History size={40} className="text-slate-400" />
            </div>
            <p className="font-bold text-slate-500">{t('noHistoryFound')}</p>
          </div>
        )}
      </div>
    </div>
  );
};