import React, { useState, useEffect, useRef } from 'react';
import { X, Lock, Phone, MessageSquare, KeyRound, CheckCircle2, AlertCircle } from 'lucide-react';
import { translations } from '../translations';
import { AdminProfile } from '../types';

interface ForgotPinModalProps {
  onBack: () => void;
  onSuccess: (newPin: string) => void;
  t: (key: keyof typeof translations['en']) => string;
}

type Step = 'phone' | 'otp' | 'reset' | 'success';

const OTP_SEND_LIMIT_KEY = 'otp_request_history';
const MAX_SENDS_PER_HOUR = 3;
const OTP_EXPIRY_MS = 300000; // 5 minutes

export const ForgotPinModal: React.FC<ForgotPinModalProps> = ({ onBack, onSuccess, t }) => {
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  
  const [error, setError] = useState('');
  const [timer, setTimer] = useState(60);
  const [verifyAttempts, setVerifyAttempts] = useState(0);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [otpExpiry, setOtpExpiry] = useState<number>(0);

  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (timer > 0 && step === 'otp') {
      timerRef.current = window.setTimeout(() => setTimer(timer - 1), 1000);
    }
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [timer, step]);

  const getProfile = (): AdminProfile => {
    const saved = localStorage.getItem('heavy_flow_profile');
    return saved ? JSON.parse(saved) : { phone: '' } as AdminProfile;
  };

  const checkThrottling = (): boolean => {
    const now = Date.now();
    const historyJson = localStorage.getItem(OTP_SEND_LIMIT_KEY);
    let history: number[] = historyJson ? JSON.parse(historyJson) : [];
    
    // Remove timestamps older than 1 hour
    history = history.filter(ts => now - ts < 3600000);
    
    if (history.length >= MAX_SENDS_PER_HOUR) {
      return false;
    }
    
    history.push(now);
    localStorage.setItem(OTP_SEND_LIMIT_KEY, JSON.stringify(history));
    return true;
  };

  const handleSendOtp = () => {
    const profile = getProfile();
    if (phone !== profile.phone) {
      setError(t('mobileNotLinked'));
      return;
    }

    if (!checkThrottling()) {
      setError(t('maxAttemptsReached'));
      return;
    }
    
    // Generate 6-digit OTP
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpExpiry(Date.now() + OTP_EXPIRY_MS); 
    setTimer(60);
    setVerifyAttempts(0);
    setError('');
    setStep('otp');
    
    // Simulation: In a real app, this would call an SMS Gateway.
    console.log(`%c [RECOVERY] OTP SENT: ${code}`, 'background: #f59e0b; color: #fff; padding: 5px; font-weight: bold;');
    alert(`OTP sent to your registered mobile number: ${code} (Simulation)`);
  };

  const handleVerifyOtp = () => {
    if (Date.now() > otpExpiry) {
      setError(t('otpExpired'));
      return;
    }
    
    if (otp === generatedOtp) {
      setError('');
      setStep('reset');
      // OTP is used, clear it so it can't be reused
      setGeneratedOtp(''); 
    } else {
      const nextAttempts = verifyAttempts + 1;
      setVerifyAttempts(nextAttempts);
      if (nextAttempts >= 3) {
        setError(t('maxAttemptsReached'));
        // Force back to phone step if attempts exceeded for this OTP
        setTimeout(() => setStep('phone'), 2000);
      } else {
        setError(`${t('incorrectPin')} (${3 - nextAttempts} attempts left)`);
      }
    }
  };

  const handleResetPin = () => {
    if (newPin.length < 4) {
      setError('PIN must be 4-6 digits');
      return;
    }
    if (newPin !== confirmPin) {
      setError('PINs do not match');
      return;
    }
    setStep('success');
    // Actual storage update happens via the parent's onSuccess
    setTimeout(() => {
      onSuccess(newPin);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[600] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-6 dark:bg-slate-900 animate-in zoom-in-95 duration-200">
        <div className="flex justify-between items-center border-b pb-4 dark:border-slate-800">
          <h2 className="text-xl font-bold dark:text-white">{t('forgotPin')}</h2>
          <button onClick={onBack} className="p-2 text-slate-400 hover:text-slate-600 transition-colors"><X size={20} /></button>
        </div>

        {step === 'phone' && (
          <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
            <div className="text-center">
              <div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-amber-900/20">
                <Phone className="text-amber-500" size={32} />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{t('enterRegisteredPhone')}</p>
            </div>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-slate-400 group-focus-within:text-amber-500 transition-colors pointer-events-none">
                <Phone size={20} />
                <span className="text-lg font-bold border-r border-slate-200 dark:border-slate-700 pr-2">+91</span>
              </div>
              <input 
                type="tel" 
                maxLength={10} 
                autoFocus 
                className={`w-full pl-28 pr-4 py-4 bg-slate-50 border rounded-2xl text-left text-xl font-bold outline-none dark:bg-slate-800 dark:text-white transition-all ${error ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-slate-200 focus:border-amber-500'}`} 
                placeholder="**********" 
                value={phone} 
                onChange={e => {setPhone(e.target.value.replace(/\D/g, '')); setError('');}} 
              />
            </div>
            {error && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{error}</p>}
            <button 
              onClick={handleSendOtp} 
              disabled={phone.length !== 10}
              className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {t('otpSent')}
            </button>
          </div>
        )}

        {step === 'otp' && (
          <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
            <div className="text-center">
              <div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-amber-900/20">
                <MessageSquare className="text-amber-500" size={32} />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{t('enterOtp')}</p>
              <div className="mt-2">
                {timer > 0 ? (
                  <p className="text-[10px] text-slate-400 uppercase font-black">{t('resendOtp')} in {timer}s</p>
                ) : (
                  <button onClick={handleSendOtp} className="text-[10px] text-amber-500 font-black uppercase hover:underline">
                    {t('resendOtp')} Now
                  </button>
                )}
              </div>
            </div>
            <input 
              type="password" 
              inputMode="numeric" 
              maxLength={6} 
              autoFocus 
              className={`w-full p-4 bg-slate-50 border rounded-2xl text-center text-3xl font-black tracking-[0.5em] outline-none dark:bg-slate-800 dark:text-white transition-all ${error ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-slate-200 focus:border-amber-500'}`} 
              placeholder="••••••" 
              value={otp} 
              onChange={e => {setOtp(e.target.value.replace(/\D/g, '')); setError('');}} 
            />
            {error && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{error}</p>}
            <button 
              onClick={handleVerifyOtp} 
              disabled={otp.length !== 6 || verifyAttempts >= 3}
              className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {t('verifyOtp')}
            </button>
          </div>
        )}

        {step === 'reset' && (
          <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
            <div className="text-center">
              <div className="bg-emerald-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-emerald-900/20">
                <KeyRound className="text-emerald-500" size={32} />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{t('setNewPin')}</p>
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">{t('newPin')}</label>
                <input 
                  type="password" 
                  inputMode="numeric" 
                  maxLength={6} 
                  autoFocus
                  className="w-full p-4 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-2xl text-center text-xl font-bold dark:bg-slate-800 dark:text-white outline-none transition-all" 
                  value={newPin} 
                  onChange={e => setNewPin(e.target.value.replace(/\D/g, ''))} 
                  placeholder="••••" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">{t('confirmNewPin')}</label>
                <input 
                  type="password" 
                  inputMode="numeric" 
                  maxLength={6} 
                  className="w-full p-4 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-2xl text-center text-xl font-bold dark:bg-slate-800 dark:text-white outline-none transition-all" 
                  value={confirmPin} 
                  onChange={e => setConfirmPin(e.target.value.replace(/\D/g, ''))} 
                  placeholder="••••" 
                />
              </div>
            </div>
            {error && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{error}</p>}
            <button 
              onClick={handleResetPin} 
              disabled={newPin.length < 4 || newPin !== confirmPin}
              className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {t('updatePin')}
            </button>
          </div>
        )}

        {step === 'success' && (
          <div className="py-8 text-center animate-in zoom-in-95 duration-500">
            <div className="bg-emerald-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 dark:bg-emerald-900/20">
              <CheckCircle2 className="text-emerald-500" size={48} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">{t('pinResetSuccess')}</h3>
            <p className="text-slate-500 dark:text-slate-400 font-medium">{t('pinResetWait')}</p>
          </div>
        )}
      </div>
    </div>
  );
};
