
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  User, 
  Calendar, 
  Truck, 
  HardHat, 
  Receipt,
  Download,
  CheckCircle2,
  AlertCircle,
  PencilLine,
  Save,
  X,
  MessageCircle,
  Lock,
  Navigation,
  Settings2,
  Tractor as TractorIcon,
  Hash
} from 'lucide-react';
import { WorkLog, VehicleType, AdminProfile, AppSettings } from '../types';
import { jsPDF } from 'jspdf';
import { translations } from '../translations';
import { TAMIL_FONT_BASE64 } from '../fonts/tamilFont';
import { ForgotPinModal } from './ForgotPinModal';

interface WorkDetailsProps {
  log: WorkLog;
  onBack: () => void;
  onUpdate: (log: WorkLog) => void;
  settings: AppSettings;
  t: (key: keyof typeof translations['en']) => string;
}

export const WorkDetails: React.FC<WorkDetailsProps> = ({ log, onBack, onUpdate, settings, t }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPinPrompt, setShowPinPrompt] = useState(false);
  const [showForgotPin, setShowForgotPin] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [whatsappError, setWhatsappError] = useState(false);

  const [editData, setEditData] = useState({
    totalAmount: log.totalAmount,
    advancePaid: log.advancePaid,
    paidAmount: log.paidAmount,
    vehicleNumber: log.vehicleNumber || ''
  });

  const dayOfWeek = new Date(log.workDate).toLocaleDateString(settings.language === 'ta' ? 'ta-IN' : 'en-US', { weekday: 'long' });

  const handleEditClick = () => {
    if (!settings.securityEnabled) return;
    if (isEditing) {
      setIsEditing(false);
      return;
    }
    setShowPinPrompt(true);
  };

  const verifyPin = () => {
    if (pinInput === settings.pin) {
      setIsEditing(true);
      setShowPinPrompt(false);
      setPinInput('');
      setPinError(false);
    } else {
      setPinError(true);
      setPinInput('');
    }
  };

  const handleSaveEdit = () => {
    if (!settings.securityEnabled) return;
    const totalPaid = editData.advancePaid + editData.paidAmount;
    const balance = editData.totalAmount - totalPaid;
    let status: 'Paid' | 'Partial' | 'Unpaid' = 'Unpaid';
    if (balance <= 0) status = 'Paid';
    else if (totalPaid > 0) status = 'Partial';
    const updatedLog: WorkLog = {
      ...log,
      totalAmount: editData.totalAmount,
      advancePaid: editData.advancePaid,
      paidAmount: editData.paidAmount,
      balanceAmount: balance,
      status: status,
      vehicleNumber: editData.vehicleNumber
    };
    onUpdate(updatedLog);
    setIsEditing(false);
  };

  const getAdminProfile = (): AdminProfile => {
    const saved = localStorage.getItem('heavy_flow_profile');
    if (saved) return JSON.parse(saved);
    return {
      adminName: 'Owner',
      businessName: 'My Bill Manager',
      address: 'Update address in profile',
      phone: '000-000-0000',
      email: 'contact@example.com'
    };
  };

  const generatePDF = (mode: 'download' | 'blob'): Promise<Blob | void> => {
    return new Promise((resolve) => {
      setIsGenerating(true);
      const profile = getAdminProfile();
      const doc = new jsPDF();
      
      const isTamil = settings.language === 'ta';
      const fontName = isTamil ? 'TamilFont' : 'helvetica';
      
      if (isTamil) {
        doc.addFileToVFS('TamilFont.ttf', TAMIL_FONT_BASE64);
        doc.addFont('TamilFont.ttf', 'TamilFont', 'normal');
      }

      const setFont = (isBold: boolean = false) => {
        doc.setFont(fontName, isBold && !isTamil ? 'bold' : 'normal');
      };

      // Header with Business Details
      doc.setFillColor(31, 41, 55); 
      doc.rect(0, 0, 210, 40, 'F');
      doc.setTextColor(255, 255, 255);
      setFont(true);
      doc.setFontSize(24);
      doc.text(profile.businessName.toUpperCase(), 15, 20);
      doc.setFontSize(10);
      setFont(false);
      doc.text(`${profile.adminName} | ${profile.phone}`, 15, 28);
      doc.text(profile.address, 15, 33); 

      doc.setTextColor(31, 41, 55);
      setFont(true);
      doc.setFontSize(12);
      doc.text(t('billTo').toUpperCase() + ':', 15, 55);
      setFont(false);
      doc.setFontSize(14);
      doc.text(log.companyName, 15, 63); 
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139); 
      doc.text(`${t('generalLocation')}: ${log.location}`, 15, 68);
      
      setFont(true);
      doc.setTextColor(31, 41, 55);
      doc.text(t('billDetails').toUpperCase() + ':', 140, 55);
      setFont(false);
      doc.text(`${t('workDate')}: ${log.workDate}`, 140, 63); 
      doc.text(`${t('vehicle')}: ${t(log.vehicleType.toLowerCase() as any) || log.vehicleType}`, 140, 68); 
      if (log.vehicleNumber) {
        doc.text(`${t('vehicleNumber')}: ${log.vehicleNumber.toUpperCase()}`, 140, 73); 
      }
      doc.text(`${t('time')}: ${log.startTime} - ${log.endTime}`, 140, log.vehicleNumber ? 78 : 73); 
      
      let nextLineY = log.vehicleNumber ? 83 : 78;
      if (log.tractorWorkType) {
        doc.text(`${t('implement')}: ${log.tractorWorkType}`, 140, nextLineY);
        nextLineY += 5;
      }
      
      // Billing Table
      doc.setFillColor(248, 250, 252); 
      doc.rect(15, 100, 180, 12, 'F');
      setFont(true);
      doc.text(t('description').toUpperCase(), 20, 108);
      doc.text(t('amount').toUpperCase(), 170, 108);
      doc.line(15, 112, 195, 112);
      
      setFont(false);
      doc.text(log.tractorWorkType ? `${log.tractorWorkType} ${t('workAt')} ${log.location}` : `${t('workDetails')} ${t('workAt')} ${log.location}`, 20, 120);
      doc.text(`${t('currency')} ${log.totalAmount.toLocaleString()}`, 170, 120);
      
      // SUMMARY SECTIONS
      const startY = 145;
      const totalPaidValue = log.advancePaid + log.paidAmount;
      const isFullyPaid = log.totalAmount === totalPaidValue;

      // 1. LEFT SIDE: DYNAMIC PAYMENT SUMMARY BOX
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setFillColor(248, 250, 252); // slate-50
      doc.roundedRect(15, startY - 8, 85, isFullyPaid ? 20 : 35, 3, 3, 'FD');

      doc.setTextColor(31, 41, 55);
      doc.setFontSize(10);
      setFont(true);
      doc.text(t('billingSummary').toUpperCase(), 20, startY);
      doc.line(20, startY + 2, 85, startY + 2);

      setFont(false);
      doc.setFontSize(9);
      
      if (isFullyPaid) {
        // Rule 1: Only show PAID amount in green
        doc.setTextColor(5, 150, 105); // Emerald-600
        setFont(true);
        doc.text(`${t('paid').toUpperCase()} : ${t('currency')} ${totalPaidValue.toLocaleString()}`, 20, startY + 10);
      } else {
        // Rule 2: Show full breakdown
        doc.text(`${t('totalAmount')} : ${t('currency')} ${log.totalAmount.toLocaleString()}`, 20, startY + 8);
        doc.text(`${t('paid')} : ${t('currency')} ${totalPaidValue.toLocaleString()}`, 20, startY + 14);
        
        doc.setTextColor(190, 18, 60); // Rose-700
        setFont(true);
        doc.text(`${t('balanceDue')} : ${t('currency')} ${log.balanceAmount.toLocaleString()}`, 20, startY + 22);
      }

      // 2. RIGHT SIDE: EXISTING SUMMARY
      doc.setTextColor(31, 41, 55);
      doc.setFontSize(11);
      setFont(false);

      if (isFullyPaid) {
        doc.setTextColor(5, 150, 105);
        setFont(true);
        doc.text(`${t('paid').toUpperCase()}:`, 130, startY); 
        doc.text(`${t('currency')} ${totalPaidValue.toLocaleString()}`, 170, startY);
      } else {
        doc.text(`${t('totalAmount')}:`, 130, startY); 
        doc.text(`${t('currency')} ${log.totalAmount.toLocaleString()}`, 170, startY);
        
        doc.text(`${t('paid')}:`, 130, startY + 8); 
        doc.text(`${t('currency')} ${totalPaidValue.toLocaleString()}`, 170, startY + 8);
        
        doc.line(130, startY + 12, 195, startY + 12);
        
        doc.setTextColor(190, 18, 60);
        setFont(true);
        doc.text(`${t('balanceDue')}:`, 130, startY + 20); 
        doc.text(`${t('currency')} ${log.balanceAmount.toLocaleString()}`, 170, startY + 20);
      }
      
      // Footer
      doc.setTextColor(148, 163, 184); 
      doc.setFontSize(8);
      setFont(false);
      doc.text(t('footerThankYou'), 105, 280, { align: 'center' });
      
      const fileName = `Bill_${log.companyName.replace(/\s+/g, '_')}_${log.workDate}.pdf`;
      if (mode === 'download') {
        doc.save(fileName);
        setIsGenerating(false);
        resolve();
      } else {
        const blob = doc.output('blob');
        setIsGenerating(false);
        resolve(blob);
      }
    });
  };

  const handleWhatsAppShare = async () => {
    try {
      const pdfBlob = await generatePDF('blob') as Blob;
      const fileName = `Bill_${log.companyName.replace(/\s+/g, '_')}_${log.workDate}.pdf`;
      const pdfFile = new File([pdfBlob], fileName, { type: 'application/pdf' });

      if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
        await navigator.share({
          files: [pdfFile],
          title: fileName,
          text: `Bill for ${log.companyName} - ${log.workDate}`
        });
      } else {
        alert("WhatsApp is not installed on your device or file sharing is not supported by your browser.");
      }
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') {
        console.error("Sharing failed", err);
        alert("Sharing failed. Please try downloading the PDF instead.");
      }
    }
  };

  const calculatedBalance = editData.totalAmount - (editData.advancePaid + editData.paidAmount);

  return (
    <div className="fixed inset-0 bg-slate-50 z-[100] overflow-y-auto pb-32 dark:bg-slate-950 transition-colors">
      <div className="bg-white border-b sticky top-0 z-10 px-4 py-4 flex items-center justify-between dark:bg-slate-900 dark:border-slate-800 transition-colors">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-600 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"><ArrowLeft className="w-6 h-6" /></button>
          <h1 className="text-xl font-bold truncate dark:text-white">{isEditing ? t('edit') : t('workDetails')}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleEditClick} 
            disabled={!settings.securityEnabled && !isEditing}
            className={`p-2 rounded-xl flex items-center space-x-1 font-bold transition-colors ${isEditing ? 'bg-rose-50 text-rose-600 dark:bg-rose-900/30' : !settings.securityEnabled ? 'bg-slate-100 text-slate-400 opacity-60' : 'bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400'}`}
          >
            {isEditing ? <X size={18} /> : <PencilLine size={18} />}
            <span className="text-xs">{isEditing ? t('cancel') : t('edit')}</span>
          </button>
        </div>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border dark:bg-slate-900 dark:border-slate-800 transition-colors">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h2 className="text-2xl font-black text-slate-900 leading-tight dark:text-white">{log.companyName}</h2>
              {!isEditing && (
                <div className={`mt-2 inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${log.status === 'Paid' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : log.status === 'Partial' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'}`}>
                  {log.status === 'Paid' ? <CheckCircle2 size={12} className="mr-1" /> : <AlertCircle size={12} className="mr-1" />}
                  {t(log.status.toLowerCase() as any)}
                </div>
              )}
            </div>
            <div className={`p-4 rounded-2xl ${log.vehicleType === VehicleType.BACKHOE ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/30' : log.vehicleType === VehicleType.TRACTOR ? 'bg-orange-100 text-orange-600 dark:bg-orange-900/30' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30'}`}>
              {log.vehicleType === VehicleType.BACKHOE ? <HardHat size={32} /> : log.vehicleType === VehicleType.TRACTOR ? <TractorIcon size={32} /> : <Truck size={32} />}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t dark:border-slate-800 transition-colors">
            <div className="flex items-center gap-3"><div className="bg-slate-50 p-2 rounded-lg text-slate-400 dark:bg-slate-700"><User size={16} /></div><div><p className="text-[10px] font-bold text-slate-400 uppercase">{t('driver')}</p><p className="text-xs font-bold dark:text-white">{log.driverName}</p></div></div>
            <div className="flex items-center gap-3"><div className="bg-slate-50 p-2 rounded-lg text-slate-400 dark:bg-slate-700"><MapPin size={16} /></div><div><p className="text-[10px] font-bold text-slate-400 uppercase">{t('generalLocation')}</p><p className="text-xs font-bold dark:text-white">{log.location}</p></div></div>
            <div className="flex items-center gap-3"><div className="bg-slate-50 p-2 rounded-lg text-slate-400 dark:bg-slate-700"><Calendar size={16} /></div><div><p className="text-[10px] font-bold text-slate-400 uppercase">{t('workDate')}</p><p className="text-xs font-bold dark:text-white">{log.workDate}</p></div></div>
            <div className="flex items-center gap-3"><div className="bg-slate-50 p-2 rounded-lg text-slate-400 dark:bg-slate-700"><Hash size={16} /></div><div><p className="text-[10px] font-bold text-slate-400 uppercase">{t('vehicleNumber')}</p><p className="text-xs font-bold dark:text-white uppercase">{log.vehicleNumber || '-'}</p></div></div>
          </div>
        </div>

        <div className="bg-white border p-6 rounded-3xl shadow-sm dark:bg-black dark:border-white/10 transition-colors relative overflow-hidden">
          <Receipt size={100} className="absolute -right-6 -bottom-6 opacity-5 dark:opacity-10 pointer-events-none" />
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2 tracking-tight dark:text-white"><Receipt className="text-amber-500" size={20} /> {t('billingSummary')}</h3>
          <div className="space-y-4 relative z-10">
            {isEditing ? (
              <div className="space-y-4 animate-in fade-in duration-300">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('vehicleNumber')}</label>
                  <input type="text" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white font-bold uppercase" value={editData.vehicleNumber} onChange={e => setEditData({...editData, vehicleNumber: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('totalAmount')}</label>
                  <input type="number" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white font-bold" value={editData.totalAmount} onChange={e => setEditData({...editData, totalAmount: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('advance')}</label>
                    <input type="number" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white font-bold" value={editData.advancePaid} onChange={e => setEditData({...editData, advancePaid: parseFloat(e.target.value) || 0})} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('paid')}</label>
                    <input type="number" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl dark:bg-slate-800 dark:border-slate-700 dark:text-white font-bold" value={editData.paidAmount} onChange={e => setEditData({...editData, paidAmount: parseFloat(e.target.value) || 0})} />
                  </div>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-500">{t('pendingBalance')}</span>
                  <span className={`text-lg font-black ${calculatedBalance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>₹{calculatedBalance.toLocaleString()}</span>
                </div>
              </div>
            ) : (
              <>
                <div className="flex justify-between text-slate-500 dark:text-slate-400 text-sm">
                  <span>{t('total')} ({log.distanceKm ? `${log.distanceKm} KM` : `${log.hoursWorked} hrs`})</span>
                  <span className="font-bold text-slate-900 dark:text-white">₹{log.totalAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-500 dark:text-slate-400 text-sm">
                  <span>{t('advance')}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{log.advancePaid.toLocaleString()}</span>
                </div>
                {log.paidAmount > 0 && (
                  <div className="flex justify-between text-slate-500 dark:text-slate-400 text-sm">
                    <span>{t('paid')} (Addl.)</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{log.paidAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="pt-4 border-t border-slate-200 dark:border-white/10 flex justify-between items-end">
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{t('paid')}</p>
                    <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">₹{(log.advancePaid + log.paidAmount).toLocaleString()}</p>
                  </div>
                  {log.balanceAmount > 0 && (
                    <div className="text-right">
                      <p className="text-[10px] font-bold text-rose-600 dark:text-rose-500 uppercase tracking-widest">{t('pendingBalance')}</p>
                      <p className="text-xl font-black text-rose-600 dark:text-rose-400">₹{log.balanceAmount.toLocaleString()}</p>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        <div className="space-y-3 pb-24">
          {isEditing ? (
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => setIsEditing(false)} className="py-5 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300">{t('cancel')}</button>
              <button onClick={handleSaveEdit} className="py-5 bg-amber-500 text-white rounded-2xl font-bold flex items-center justify-center gap-2"><Save size={20} /> <span>{t('save')}</span></button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <button disabled={isGenerating} onClick={() => generatePDF('download')} className="py-4 bg-white border border-slate-200 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-sm dark:bg-slate-900 dark:border-slate-800 dark:text-white disabled:opacity-50"><Download size={20} className="text-amber-500" /><span>{isGenerating ? t('wait') : t('download')}</span></button>
                <button disabled={isGenerating} onClick={handleWhatsAppShare} className="py-4 bg-emerald-500 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"><MessageCircle size={20} /><span>WhatsApp</span></button>
              </div>
              <button onClick={onBack} className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-bold shadow-xl dark:bg-black">{t('done')}</button>
            </>
          )}
        </div>
      </div>

      {showPinPrompt && (
        <div className="fixed inset-0 z-[300] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-6 dark:bg-slate-900">
            <div className="text-center"><div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 dark:bg-amber-900/20"><Lock className="text-amber-500" size={32} /></div><h2 className="text-xl font-bold dark:text-white">{t('enterPin')}</h2><p className="text-sm text-slate-500 dark:text-slate-400">{t('enterPinToEdit')}</p></div>
            <input type="password" inputMode="numeric" maxLength={6} autoFocus className={`w-full p-5 bg-slate-50 border rounded-2xl text-center text-3xl font-black tracking-[0.5em] outline-none dark:bg-slate-800 dark:text-white ${pinError ? 'border-rose-500' : 'border-slate-200'}`} placeholder="••••" value={pinInput} onChange={e => {setPinInput(e.target.value.replace(/\D/g, '')); setPinError(false);}} onKeyDown={e => e.key === 'Enter' && verifyPin()} />
            {pinError && <p className="text-rose-500 text-center font-bold text-[10px] uppercase">{t('incorrectPin')}</p>}
            <div className="flex justify-end px-1">
              <button 
                type="button" 
                onClick={() => { setShowPinPrompt(false); setShowForgotPin(true); }}
                className="text-xs font-bold text-amber-600 dark:text-amber-500 hover:underline"
              >
                {t('forgotPin')}
              </button>
            </div>
            <div className="flex gap-3"><button onClick={() => {setShowPinPrompt(false); setPinInput(''); setPinError(false);}} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold dark:bg-slate-800 dark:text-slate-300">{t('cancel')}</button><button onClick={verifyPin} className="flex-1 py-4 bg-amber-500 text-white rounded-2xl font-bold">{t('verify')}</button></div>
          </div>
        </div>
      )}

      {showForgotPin && (
        <ForgotPinModal 
          t={t} 
          onBack={() => setShowForgotPin(false)}
          onSuccess={(newPin) => {
            const currentSettings = JSON.parse(localStorage.getItem('heavy_flow_settings') || '{}');
            const updatedSettings = { ...currentSettings, pin: newPin };
            localStorage.setItem('heavy_flow_settings', JSON.stringify(updatedSettings));
            setShowForgotPin(false);
            alert(t('pinResetSuccess'));
          }}
        />
      )}
    </div>
  );
};
