import React, { useState, useEffect, useRef } from 'react';
import { 
  Save, 
  User, 
  ArrowLeft, 
  Pencil,
  X,
  Home,
  Camera
} from 'lucide-react';
import { AdminProfile, AppSettings } from '../types';
import { translations } from '../translations';

interface ProfileViewProps {
  onBack: () => void;
  settings: AppSettings;
  t: (key: keyof typeof translations['en']) => string;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onBack, settings, t }) => {
  const [isEditing, setIsEditing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profile, setProfile] = useState<AdminProfile>({
    adminName: '',
    businessName: '',
    address: '',
    phone: '',
    email: '',
    profileImage: ''
  });

  useEffect(() => {
    const savedProfile = localStorage.getItem('heavy_flow_profile');
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('heavy_flow_profile', JSON.stringify(profile));
    setIsEditing(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfile(prev => ({ ...prev, profileImage: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileUpload = () => {
    if (isEditing) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-slate-50 dark:bg-slate-950 transition-colors overflow-hidden">
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.05]" style={{ backgroundImage: `radial-gradient(#f59e0b 1px, transparent 1px)`, backgroundSize: '32px 32px' }}></div>
      <div className="fixed inset-0 pointer-events-none bg-gradient-to-br from-amber-500/5 via-transparent to-orange-500/5 dark:from-amber-500/10 dark:to-slate-900/50"></div>
      
      <div className="bg-white border-b border-slate-100 sticky top-0 z-10 px-4 py-4 flex items-center justify-between dark:bg-slate-900 dark:border-slate-800 transition-colors">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-50 rounded-full dark:hover:bg-slate-800 transition-colors dark:text-slate-300">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold dark:text-white">{t('adminProfile')}</h1>
        </div>
        {!isEditing ? (
          <button 
            onClick={() => setIsEditing(true)}
            className="px-4 py-2 bg-amber-50 text-amber-600 rounded-xl font-bold text-sm flex items-center gap-2 dark:bg-amber-900/30 dark:text-amber-400"
          >
            <Pencil size={16} /> {t('edit')}
          </button>
        ) : (
          <button 
            onClick={() => setIsEditing(false)}
            className="p-2 text-slate-400 hover:bg-slate-50 rounded-full dark:hover:bg-slate-800 transition-colors"
          >
            <X size={24} />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-xl mx-auto p-6 space-y-8 pb-32">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative group">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                className="hidden" 
                accept="image/*" 
              />
              <div 
                onClick={triggerFileUpload}
                className={`w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden bg-slate-100 flex items-center justify-center transition-all dark:bg-slate-800 dark:border-slate-700 ${isEditing ? 'cursor-pointer hover:border-amber-500' : 'pointer-events-none'}`}
              >
                {profile.profileImage ? (
                  <img src={profile.profileImage} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User size={48} className="text-slate-300 dark:text-slate-600" />
                )}
              </div>
              {isEditing && (
                <div 
                  onClick={triggerFileUpload}
                  className="absolute bottom-1 right-1 bg-amber-500 p-2 rounded-full text-white shadow-lg cursor-pointer hover:bg-amber-600 transition-colors"
                >
                  <Camera size={16} />
                </div>
              )}
            </div>
            <div className="text-center">
              <h2 className="text-xl font-black text-slate-900 dark:text-white">{profile.businessName || t('businessName')}</h2>
              <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">{profile.adminName || t('profile')}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('adminName')}</label>
              {isEditing ? (
                <input type="text" className="w-full px-4 py-4 bg-white border border-slate-200 rounded-2xl dark:bg-slate-800 dark:text-white" value={profile.adminName} onChange={e => setProfile({...profile, adminName: e.target.value})} />
              ) : (
                <p className="p-4 bg-white rounded-2xl font-bold text-slate-700 border border-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800">{profile.adminName || t('notSet')}</p>
              )}
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('businessName')}</label>
              {isEditing ? (
                <input type="text" className="w-full px-4 py-4 bg-white border border-slate-200 rounded-2xl dark:bg-slate-800 dark:text-white" value={profile.businessName} onChange={e => setProfile({...profile, businessName: e.target.value})} />
              ) : (
                <p className="p-4 bg-white rounded-2xl font-bold text-slate-700 border border-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800">{profile.businessName || t('notSet')}</p>
              )}
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('address')}</label>
              {isEditing ? (
                <textarea className="w-full px-4 py-4 bg-white border border-slate-200 rounded-2xl dark:bg-slate-800 dark:text-white" value={profile.address} onChange={e => setProfile({...profile, address: e.target.value})} />
              ) : (
                <p className="p-4 bg-white rounded-2xl font-bold text-slate-700 border border-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800 whitespace-pre-wrap">{profile.address || t('notSet')}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('phone')}</label>
                {isEditing ? (
                  <input type="tel" maxLength={10} className="w-full px-4 py-4 bg-white border border-slate-200 rounded-2xl dark:bg-slate-800 dark:text-white" value={profile.phone} onChange={e => setProfile({...profile, phone: e.target.value.replace(/\D/g, '')})} />
                ) : (
                  <p className="p-4 bg-white rounded-2xl font-bold text-slate-700 border border-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800">{profile.phone || t('notSet')}</p>
                )}
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('email')}</label>
                {isEditing ? (
                  <input type="email" className="w-full px-4 py-4 bg-white border border-slate-200 rounded-2xl dark:bg-slate-800 dark:text-white" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})} />
                ) : (
                  <p className="p-4 bg-white rounded-2xl font-bold text-slate-700 border border-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800 truncate">{profile.email || t('notSet')}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 bg-white border-t dark:bg-slate-900 dark:border-slate-800 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.05)] pb-24 sm:pb-28">
        <div className="max-w-xl mx-auto space-y-3">
          {isEditing && (
            <button onClick={handleSave} className="w-full py-5 rounded-2xl font-bold bg-amber-500 text-white shadow-xl flex items-center justify-center gap-2"><Save size={20} /><span>{t('saveProfile')}</span></button>
          )}
          <button onClick={onBack} className="w-full py-5 rounded-2xl font-bold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 transition-all flex items-center justify-center gap-2"><Home size={20} /><span>{t('backToHome')}</span></button>
        </div>
      </div>
    </div>
  );
};