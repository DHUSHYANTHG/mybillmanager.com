import React, { useState, useMemo } from 'react';
import { ArrowLeft, TrendingUp, Calendar, ChevronRight, BarChart3 } from 'lucide-react';
import { WorkLog, AppSettings } from '../types';
import { translations } from '../translations';

interface RevenueAnalyticsProps {
  logs: WorkLog[];
  onBack: () => void;
  settings: AppSettings;
  t: (key: keyof typeof translations['en']) => string;
}

type TimeRange = 'today' | 'week' | 'month';

export const RevenueAnalytics: React.FC<RevenueAnalyticsProps> = ({ logs, onBack, settings, t }) => {
  const [range, setRange] = useState<TimeRange>('today');

  const chartData = useMemo(() => {
    const now = new Date();
    const data: { label: string; value: number }[] = [];

    if (range === 'today') {
      const hourly = new Array(24).fill(0);
      const todayStr = now.toISOString().split('T')[0];
      logs.forEach(log => {
        if (log.workDate === todayStr) {
          const hour = parseInt(log.startTime.split(':')[0]);
          if (!isNaN(hour)) hourly[hour] += log.totalAmount;
        }
      });
      hourly.forEach((val, i) => {
        if (i % 4 === 0 || val > 0) {
          data.push({ label: `${i}:00`, value: val });
        }
      });
    } else if (range === 'week') {
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        const dayLabel = d.toLocaleDateString(settings.language === 'ta' ? 'ta-IN' : 'en-US', { weekday: 'short' });
        const dayTotal = logs.filter(l => l.workDate === dateStr).reduce((sum, l) => sum + l.totalAmount, 0);
        data.push({ label: dayLabel, value: dayTotal });
      }
    } else if (range === 'month') {
      for (let i = 25; i >= 0; i -= 5) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const dateStr = d.toLocaleDateString(settings.language === 'ta' ? 'ta-IN' : 'en-US', { month: 'short', day: 'numeric' });
        let windowTotal = 0;
        for (let j = 0; j < 5; j++) {
           const checkDate = new Date();
           checkDate.setDate(now.getDate() - (i - j));
           const checkStr = checkDate.toISOString().split('T')[0];
           windowTotal += logs.filter(l => l.workDate === checkStr).reduce((sum, l) => sum + l.totalAmount, 0);
        }
        data.push({ label: dateStr, value: windowTotal });
      }
    }
    return data;
  }, [logs, range, settings.language]);

  const maxValue = Math.max(...chartData.map(d => d.value), 1000);
  const totalInRange = chartData.reduce((sum, d) => sum + d.value, 0);

  return (
    <div className="fixed inset-0 bg-slate-50 z-[80] overflow-y-auto pb-32 dark:bg-slate-950 transition-colors">
      <div className="bg-white border-b sticky top-0 z-10 px-4 py-4 flex items-center justify-between dark:bg-slate-900 dark:border-slate-800">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full dark:hover:bg-slate-800 dark:text-white"><ArrowLeft className="w-6 h-6" /></button>
          <h1 className="text-xl font-bold dark:text-white">{t('revenueAnalytics')}</h1>
        </div>
      </div>

      <div className="max-w-xl mx-auto p-4 space-y-6">
        <div className="bg-white border rounded-3xl p-6 text-slate-900 shadow-sm relative overflow-hidden dark:bg-black dark:text-white dark:border-white/10 transition-colors">
          <TrendingUp size={120} className="absolute -right-8 -bottom-8 opacity-5 dark:opacity-10" />
          <div className="relative z-10">
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest dark:text-slate-400">{t('totalRevenue')} ({t(range as any)})</p>
            <h2 className="text-4xl font-black mt-1">₹{totalInRange.toLocaleString()}</h2>
            <div className="mt-4 flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs bg-emerald-50 dark:bg-emerald-400/10 w-fit px-3 py-1 rounded-full"><TrendingUp size={14} /><span>{t('healthyGrowth')}</span></div>
          </div>
        </div>

        <div className="flex p-1 bg-white border border-slate-200 rounded-2xl dark:bg-slate-900 dark:border-slate-800 transition-colors">
          {(['today', 'week', 'month'] as const).map((r) => (
            <button key={r} onClick={() => setRange(r)} className={`flex-1 py-3 text-xs font-black uppercase tracking-widest rounded-xl transition-all ${range === r ? 'bg-amber-500 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800'}`}>{t(r as any)}</button>
          ))}
        </div>

        <div className="bg-white p-6 rounded-3xl border dark:bg-slate-900 dark:border-slate-800 transition-colors">
          <div className="flex items-center justify-between mb-8"><h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2"><BarChart3 className="text-amber-500" size={18} />{t('revenueTrend')}</h3><span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('liveUpdates')}</span></div>
          {totalInRange > 0 ? (
            <div className="flex-1 flex items-end justify-between gap-2 h-48 mt-4">
              {chartData.map((d, i) => (
                <div key={i} className="flex-1 flex flex-col items-center group cursor-default">
                  <div className="w-full relative flex flex-col justify-end h-40">
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20 shadow-sm">₹{d.value.toLocaleString()}</div>
                    <div className="w-full bg-amber-500 rounded-t-lg transition-all duration-500 group-hover:bg-amber-400" style={{ height: `${(d.value / maxValue) * 100}%`, minHeight: d.value > 0 ? '4px' : '0' }} />
                  </div>
                  <span className="text-[8px] font-bold text-slate-400 uppercase mt-2 transform -rotate-45 sm:rotate-0 whitespace-nowrap">{d.label}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-3 opacity-50 text-slate-400 dark:text-slate-500"><div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-full"><Calendar size={32} /></div><p className="font-bold text-sm">No revenue recorded for {t(range as any)}</p></div>
          )}
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 dark:bg-slate-900 dark:border-slate-800 transition-colors flex items-center justify-between">
          <div className="flex items-center gap-4"><div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-2xl text-blue-600 dark:text-blue-400"><Calendar size={20} /></div><div><h4 className="font-bold text-slate-900 dark:text-white">{t('highestEarning')}</h4><p className="text-xs text-slate-500 dark:text-slate-400">{t('peakPerformance')}</p></div></div>
          <div className="text-right"><p className="text-lg font-black text-slate-900 dark:text-white">₹{maxValue.toLocaleString()}</p><p className="text-[10px] font-bold text-slate-400 uppercase">PEAK</p></div>
        </div>

        <button onClick={onBack} className="w-full py-5 bg-slate-900 text-white rounded-2xl font-bold shadow-xl active:scale-95 transition-all mt-4 dark:bg-black">{t('backToDashboard')}</button>
      </div>
    </div>
  );
};