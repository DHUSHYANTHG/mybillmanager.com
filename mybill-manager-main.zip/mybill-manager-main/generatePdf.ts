import jsPDF from "jspdf";
import { TAMIL_FONT_BASE64 } from "./fonts/tamilFont";

type Lang = "en" | "ta";

export function generateBillPDF(data: any, lang: Lang) {
  const doc = new jsPDF();

  try {
    if (lang === "ta") {
      doc.addFileToVFS("Tamil.ttf", TAMIL_FONT_BASE64);
      doc.addFont("Tamil.ttf", "Tamil", "normal");
      doc.setFont("Tamil");
    } else {
      doc.setFont("Helvetica");
    }
  } catch (e) {
    console.error("Font load failed", e);
    doc.setFont("Helvetica");
  }

  // ---------- CONTENT ----------
  doc.setFontSize(16);
  doc.text(
    lang === "ta" ? "பில் விவரம்" : "Bill Details",
    14,
    20
  );

  doc.setFontSize(12);
  doc.text(
    `${lang === "ta" ? "பெயர்" : "Name"}: ${data.name}`,
    14,
    35
  );

  doc.text(
    `${lang === "ta" ? "மொத்த தொகை" : "Total Amount"}: ₹${data.total}`,
    14,
    45
  );

  doc.text(
    `${lang === "ta" ? "செலுத்தப்பட்டது" : "Paid"}: ₹${data.paid}`,
    14,
    55
  );

  doc.text(
    `${lang === "ta" ? "மீதம்" : "Balance"}: ₹${data.balance}`,
    14,
    65
  );

  return doc;
}
