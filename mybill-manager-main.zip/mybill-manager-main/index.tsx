
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Global handler for network or chunk errors (common when switching between SIM and Wi-Fi)
window.addEventListener('error', (e: any) => {
  const message = e?.message || '';
  if (typeof message === 'string') {
    const isNetworkError = 
      message.includes('Loading chunk') || 
      message.includes('CSS chunk') || 
      message.includes('Failed to fetch') ||
      message.includes('NetworkError');
    
    if (isNetworkError) {
      console.warn('Network change or disruption detected. Attempting to stabilize...');
      // Only reload if we are actually online to avoid infinite loops
      if (navigator.onLine) {
        window.location.reload();
      }
    }
  }
}, true);

// Apply theme immediately on load from localStorage
const safeApplyTheme = () => {
  try {
    const savedSettingsStr = localStorage.getItem('heavy_flow_settings');
    if (savedSettingsStr) {
      const savedSettings = JSON.parse(savedSettingsStr);
      if (savedSettings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  } catch (e) {
    console.error("Theme recovery failed", e);
  }
};

safeApplyTheme();

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

try {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} catch (error) {
  console.error("Critical rendering error:", error);
  rootElement.innerHTML = `<div style="padding: 20px; font-family: sans-serif; text-align: center; background: #fff; height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">
    <h1 style="color: #f59e0b;">Connection Error</h1>
    <p style="color: #64748b;">The app couldn't start. This usually happens during a network switch.</p>
    <button onclick="window.location.reload()" style="padding: 12px 24px; background: #f59e0b; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer;">Try Again</button>
  </div>`;
}
