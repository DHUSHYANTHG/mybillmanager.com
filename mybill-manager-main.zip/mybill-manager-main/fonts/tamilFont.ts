// Arima Madurai Regular – Tamil Unicode font
// Safe multi-line Base64 using backticks

export const TAMIL_FONT_BASE64 = `AAEAAAALAIAAAwAwT1MvMg8SBTkAAAC8AAAAYGNtYXAA`; // Minimal placeholder to prevent syntax errors
