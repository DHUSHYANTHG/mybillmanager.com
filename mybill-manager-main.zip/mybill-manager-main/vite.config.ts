
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    emptyOutDir: true,
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'lucide-react', 'jspdf'],
        },
      },
    },
  },
  server: {
    port: 3000,
    strictPort: true,
    // Fix: Removed historyApiFallback as it is not a valid property in ServerOptions.
    // Vite serves index.html for unknown paths by default in SPA mode.
  },
});
